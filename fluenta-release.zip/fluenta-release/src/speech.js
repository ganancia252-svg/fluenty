import { getToken } from './api.js'

/* --------------------------------- fala (TTS) ------------------------------ */

let currentAudio = null

export function stopSpeaking() {
  try {
    window.speechSynthesis?.cancel()
  } catch {}
  if (currentAudio) {
    try {
      currentAudio.pause()
    } catch {}
    currentAudio = null
  }
}

function browserVoice() {
  const synth = window.speechSynthesis
  if (!synth) return null
  const voices = synth.getVoices() || []
  const en = voices.filter((v) => /^en(-|_)?/i.test(v.lang))
  const preferred = ['Samantha', 'Google US English', 'Microsoft Aria', 'Microsoft Jenny', 'Karen', 'Daniel']
  for (const name of preferred) {
    const hit = en.find((v) => v.name.toLowerCase().includes(name.toLowerCase()))
    if (hit) return hit
  }
  return en.find((v) => /US|American/i.test(v.name)) || en[0] || null
}

if (typeof window !== 'undefined' && window.speechSynthesis) {
  // aquece a lista de vozes (Chrome carrega async)
  window.speechSynthesis.getVoices()
  window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices()
}

/**
 * Fala um texto em inglês. Tenta o TTS do servidor (voz neural) quando o usuário
 * tem chave de IA configurada; senão, usa a voz do navegador.
 * Retorna uma promise que resolve quando o áudio termina.
 */
export async function speak(text, { serverTts = true, rate = 0.95, onStart, onEnd } = {}) {
  if (!text?.trim()) return
  stopSpeaking()
  onStart?.()

  if (serverTts) {
    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...(getToken() ? { authorization: `Bearer ${getToken()}` } : {}) },
        body: JSON.stringify({ text }),
      })
      if (res.ok && res.status !== 204) {
        const blob = await res.blob()
        const url = URL.createObjectURL(blob)
        const audio = new Audio(url)
        currentAudio = audio
        await new Promise((resolve) => {
          audio.onended = resolve
          audio.onerror = resolve
          audio.play().catch(resolve)
        })
        URL.revokeObjectURL(url)
        currentAudio = null
        onEnd?.()
        return
      }
    } catch {
      /* segue para a voz do navegador */
    }
  }

  return new Promise((resolve) => {
    const synth = window.speechSynthesis
    if (!synth) {
      onEnd?.()
      return resolve()
    }
    const u = new SpeechSynthesisUtterance(text)
    u.lang = 'en-US'
    u.rate = rate
    u.pitch = 1
    const v = browserVoice()
    if (v) u.voice = v
    u.onend = () => {
      onEnd?.()
      resolve()
    }
    u.onerror = () => {
      onEnd?.()
      resolve()
    }
    synth.speak(u)
  })
}

/* ------------------------------ escuta (STT) ------------------------------ */

export function sttSupported() {
  return typeof window !== 'undefined' && Boolean(window.SpeechRecognition || window.webkitSpeechRecognition)
}

/**
 * Cria um reconhecedor de fala em inglês (push-to-talk).
 * onPartial(texto) durante a fala; onFinal(texto) ao terminar; onEnd() sempre.
 */
export function createRecognizer({ onPartial, onFinal, onEnd, onError } = {}) {
  const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition
  if (!Ctor) {
    onError?.('unsupported')
    return null
  }
  const rec = new Ctor()
  rec.lang = 'en-US'
  rec.interimResults = true
  rec.continuous = false
  rec.maxAlternatives = 1

  let finalText = ''
  let stopped = false

  rec.onresult = (event) => {
    let interim = ''
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const r = event.results[i]
      if (r.isFinal) finalText += r[0].transcript
      else interim += r[0].transcript
    }
    onPartial?.(finalText + interim, Boolean(interim))
  }
  rec.onerror = (e) => {
    if (e.error === 'not-allowed' || e.error === 'service-not-allowed') onError?.('permission')
    else if (e.error !== 'no-speech' && e.error !== 'aborted') onError?.(e.error)
  }
  rec.onend = () => {
    stopped = true
    onEnd?.(finalText.trim())
  }

  return {
    start() {
      finalText = ''
      try {
        rec.start()
      } catch {
        onError?.('start-failed')
      }
    },
    stop() {
      if (!stopped) {
        try {
          rec.stop()
        } catch {}
      }
    },
    abort() {
      try {
        rec.abort()
      } catch {}
    },
  }
}
