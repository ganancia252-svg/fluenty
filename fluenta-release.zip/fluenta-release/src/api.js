const KEY = 'fluenta_token'

let memoryToken = null
try {
  memoryToken = localStorage.getItem(KEY)
} catch {
  memoryToken = null // iframe em sandbox sem storage
}

export function getToken() {
  return memoryToken
}

export function setToken(token) {
  memoryToken = token
  try {
    if (token) localStorage.setItem(KEY, token)
    else localStorage.removeItem(KEY)
  } catch {}
}

export class ApiError extends Error {
  constructor(message, status) {
    super(message)
    this.status = status
  }
}

export async function api(path, { method = 'GET', body, raw = false } = {}) {
  const headers = {}
  if (body !== undefined) headers['content-type'] = 'application/json'
  if (memoryToken) headers.authorization = `Bearer ${memoryToken}`

  let res
  try {
    res = await fetch(`/api${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) })
  } catch {
    throw new ApiError('Sem conexão com o servidor. Verifique se o backend está rodando.', 0)
  }

  if (res.status === 204) return null
  if (raw) return res

  const text = await res.text()
  let data = null
  try {
    data = text ? JSON.parse(text) : null
  } catch {
    data = null
  }
  if (!res.ok) throw new ApiError(data?.error || `Erro ${res.status}`, res.status)
  return data
}

export const post = (p, body) => api(p, { method: 'POST', body })
export const put = (p, body) => api(p, { method: 'PUT', body })
export const patch = (p, body) => api(p, { method: 'PATCH', body })
export const del = (p) => api(p, { method: 'DELETE' })
