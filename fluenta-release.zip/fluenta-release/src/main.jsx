import React, { useEffect, useMemo, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { api, del, getToken, patch, post, put, setToken } from './api.js'
import { createRecognizer, speak, stopSpeaking, sttSupported } from './speech.js'
import './styles.css'

const LEVELS = [
  { id: 'A1', short: 'Iniciante', description: 'Entendo palavras soltas e frases muito simples.' },
  { id: 'A2', short: 'Básico', description: 'Consigo conversar sobre assuntos previsíveis do dia a dia.' },
  { id: 'B1', short: 'Intermediário', description: 'Desenvolvo opiniões e narrativas com alguma autonomia.' },
  { id: 'B2', short: 'Avançado', description: 'Debato temas complexos e busco naturalidade.' },
]

const GOALS = [
  { id: 'conversacao', icon: '💬', label: 'Conversar sem travar' },
  { id: 'carreira', icon: '📈', label: 'Carreira e reuniões' },
  { id: 'viagem', icon: '✈️', label: 'Viagens' },
  { id: 'exames', icon: '🎯', label: 'Provas e certificações' },
]

const TEST_QUESTIONS = [
  { prompt: 'She ___ a doctor.', options: ['is', 'are', 'am', 'be'], answer: 'is' },
  { prompt: 'Yesterday I ___ to the gym.', options: ['go', 'went', 'gone', 'going'], answer: 'went' },
  { prompt: 'I have lived here ___ 2021.', options: ['for', 'since', 'during', 'from'], answer: 'since' },
  { prompt: 'If I had more time, I ___ learn French.', options: ['will', 'would', 'am', 'can'], answer: 'would' },
  { prompt: 'Could you ___ me more about the role?', options: ['tell', 'say', 'speak', 'talk'], answer: 'tell' },
  { prompt: 'Which sounds most natural?', options: ['I agree.', 'I am agree.', 'I do agreeing.', 'I agreeing.'], answer: 'I agree.' },
]

function cx(...values) {
  return values.filter(Boolean).join(' ')
}

function firstName(name = '') {
  return name.trim().split(/\s+/)[0] || 'você'
}

function greeting() {
  const hour = new Date().getHours()
  if (hour < 12) return 'Bom dia'
  if (hour < 18) return 'Boa tarde'
  return 'Boa noite'
}

function formatDate(value) {
  if (!value) return '—'
  try {
    return new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).format(new Date(value.replace(' ', 'T') + (value.endsWith('Z') ? '' : 'Z')))
  } catch {
    return value
  }
}

function Brand({ dark = false }) {
  return <div className={cx('brand', dark && 'brand-dark')}>
    <span className="logo">F</span>
    <span>Fluenta</span>
  </div>
}

function Button({ children, className = '', ...props }) {
  return <button className={cx('btn', className)} {...props}>{children}</button>
}

function Chip({ children, className = '', ...props }) {
  return <span className={cx('chip', className)} {...props}>{children}</span>
}

function ProgressRing({ value = 0, total = 15 }) {
  const radius = 52
  const circumference = 2 * Math.PI * radius
  const percent = Math.max(0, Math.min(1, total ? value / total : 0))
  return <div className="ring" aria-label={`${value} de ${total} minutos`}>
    <svg width="132" height="132" viewBox="0 0 132 132" role="img">
      <circle cx="66" cy="66" r={radius} fill="none" stroke="#e5e8ee" strokeWidth="9" />
      <circle cx="66" cy="66" r={radius} fill="none" stroke="var(--accent)" strokeWidth="9" strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={circumference * (1 - percent)} />
    </svg>
    <div className="ring-label"><div><b>{value}/{total}</b><span className="tiny muted">min hoje</span></div></div>
  </div>
}

function AuthShell({ children, eyebrow = 'Aprenda inglês conversando de verdade.', subtitle = 'Você fala, o tutor de IA responde, corrige na hora e adapta a dificuldade ao seu nível.' }) {
  return <div className="auth-wrap">
    <section className="auth-art">
      <Brand dark />
      <div className="auth-pitch">
        <h1>{eyebrow}</h1>
        <p>{subtitle}</p>
        <div className="auth-conversation" aria-hidden="true">
          <div className="bubble">Good morning! I’m Alex, your tutor. Tell me — how was your weekend?</div>
          <div className="bubble me">I go to the beach with my family! It was amazing.</div>
          <div className="bubble">Nice! Small fix: <strong>“I went to the beach with my family.”</strong> What did you enjoy most there?</div>
        </div>
      </div>
      <p className="auth-footnote">Demonstração funcional · dados salvos localmente em SQLite</p>
    </section>
    <section className="auth-form"><div className="auth-form-inner">{children}</div></section>
  </div>
}

function WelcomeScreen({ onRegister, onLogin }) {
  return <AuthShell>
    <div className="auth-card-copy">
      <h2>Crie sua conta em 2 minutos</h2>
      <p className="muted small">Sem cartão, sem aula gravada: só conversa guiada, no seu ritmo. Sua chave de IA fica salva e criptografada na sua conta.</p>
    </div>
    <div className="col" style={{ marginTop: 16 }}>
      <Button className="primary block" onClick={onRegister}>Começar agora</Button>
      <Button className="block" onClick={onLogin}>Já tenho conta</Button>
      <div className="card tight demo-note"><span className="small muted"><b>Modo demonstração:</b> sem chave de IA configurada, o tutor responde com um motor local de exemplo — dá para navegar o app inteiro e ver a mecânica.</span></div>
    </div>
  </AuthShell>
}

function LoginScreen({ onBack, onLoggedIn }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(event) {
    event.preventDefault()
    setError('')
    setLoading(true)
    try {
      const result = await post('/auth/login', { email, password })
      setToken(result.token)
      onLoggedIn(result.user)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return <AuthShell eyebrow="Volte a conversar em inglês." subtitle="Seu histórico, vocabulário e sequência ficam esperando por você.">
    <form className="card auth-panel stack" onSubmit={submit}>
      <div className="row between"><div><h2>Entrar</h2><p className="small muted" style={{ marginTop: 4 }}>Continue de onde parou.</p></div><Button type="button" className="ghost sm" onClick={onBack}>← Voltar</Button></div>
      {error && <div className="alert error">{error}</div>}
      <div className="field"><label>E-mail</label><input className="input" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
      <div className="field"><label>Senha</label><input className="input" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required /></div>
      <Button className="primary block" disabled={loading}>{loading ? 'Entrando…' : 'Entrar'}</Button>
      <p className="hint">Conta demo: <b>demo@fluenta.app</b> · senha <b>demo1234</b> (se você rodar o seed).</p>
    </form>
  </AuthShell>
}

function RegisterScreen({ onBack, onRegistered }) {
  const [step, setStep] = useState(1)
  const [data, setData] = useState({ name: '', email: '', password: '', level: 'A1', goal: 'conversacao', daily: 15 })
  const [testOpen, setTestOpen] = useState(false)
  const [testIndex, setTestIndex] = useState(0)
  const [testScore, setTestScore] = useState(0)
  const [testAnswers, setTestAnswers] = useState([])
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  function update(key, value) {
    setData((current) => ({ ...current, [key]: value }))
  }

  function nextStep(event) {
    event?.preventDefault()
    setError('')
    if (step === 1) {
      if (!data.name.trim() || !data.email.trim() || data.password.length < 6) {
        setError('Preencha nome, e-mail e uma senha com pelo menos 6 caracteres.')
        return
      }
      setStep(2)
    } else if (step === 2) {
      setStep(3)
    }
  }

  function answerTest(answer) {
    const question = TEST_QUESTIONS[testIndex]
    const nextScore = testScore + (answer === question.answer ? 1 : 0)
    setTestScore(nextScore)
    setTestAnswers((answers) => [...answers, answer])
    if (testIndex === TEST_QUESTIONS.length - 1) {
      const level = nextScore <= 1 ? 'A1' : nextScore <= 3 ? 'A2' : nextScore <= 4 ? 'B1' : 'B2'
      update('level', level)
      setTestOpen(false)
      setStep(2)
      setTestIndex(0)
      setTestScore(0)
      setTestAnswers([])
    } else {
      setTestIndex((index) => index + 1)
    }
  }

  async function finish(event) {
    event.preventDefault()
    setError('')
    setLoading(true)
    try {
      const result = await post('/auth/register', { name: data.name, email: data.email, password: data.password, cefr_level: data.level, goal: data.goal, daily_goal_min: data.daily })
      setToken(result.token)
      onRegistered(result.user)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return <AuthShell eyebrow={step === 1 ? 'Vamos começar pelo básico.' : step === 2 ? 'Calibre o desafio.' : 'Defina o ritmo.'} subtitle={step === 1 ? 'Nome, e-mail e senha. Nada de formulário infinito.' : step === 2 ? 'O tutor ajusta vocabulário, velocidade e correções conforme o seu nível. Você pode mudar depois.' : 'Metas pequenas e diárias funcionam melhor do que maratonas de domingo.'}>
    <div className="onboarding-panel">
      <div className="stepper"><span className={cx(step >= 1 && 'active')}>1. Seus dados</span><span className={cx(step >= 2 && 'active')}>2. Seu nível</span><span className={cx(step >= 3 && 'active')}>3. Sua meta</span></div>
      {error && <div className="alert error" style={{ marginBottom: 14 }}>{error}</div>}
      {step === 1 && <form className="stack" onSubmit={nextStep}>
        <div className="row between"><h2>Seus dados</h2><Button type="button" className="ghost sm" onClick={onBack}>← Voltar</Button></div>
        <div className="field"><label>Nome</label><input className="input" placeholder="Como quer ser chamado" value={data.name} onChange={(e) => update('name', e.target.value)} autoComplete="name" required /></div>
        <div className="field"><label>E-mail</label><input className="input" type="email" value={data.email} onChange={(e) => update('email', e.target.value)} autoComplete="email" required /></div>
        <div className="field"><label>Senha</label><input className="input" type="password" value={data.password} onChange={(e) => update('password', e.target.value)} autoComplete="new-password" minLength={6} required /><span className="hint">Mínimo de 6 caracteres.</span></div>
        <Button className="primary block">Continuar</Button>
      </form>}
      {step === 2 && <div className="stack">
        <div className="row between"><h2>Seu nível</h2><Button className="sm" onClick={() => setTestOpen(true)}>Teste rápido (6 perguntas)</Button></div>
        <div className="level-list">{LEVELS.map((level) => <button type="button" key={level.id} className={cx('level-option', data.level === level.id && 'selected')} onClick={() => update('level', level.id)}><span className="level-badge">{level.id}</span><span><b>{level.short}</b><small>{level.description}</small></span></button>)}</div>
        <div className="row between"><Button className="ghost" onClick={() => setStep(1)}>Voltar</Button><Button className="primary" onClick={() => setStep(3)}>Continuar</Button></div>
      </div>}
      {step === 3 && <form className="stack" onSubmit={finish}>
        <div className="row between"><div><h2>Objetivo e meta diária</h2><p className="small muted" style={{ marginTop: 4 }}>Você pode ajustar isso quando quiser no perfil.</p></div></div>
        <div className="field"><label>Meu foco principal</label><div className="goal-grid">{GOALS.map((goal) => <button type="button" key={goal.id} className={cx('goal-option', data.goal === goal.id && 'selected')} onClick={() => update('goal', goal.id)}><span>{goal.icon}</span><b>{goal.label}</b></button>)}</div></div>
        <div className="field"><label>Meta diária: {data.daily} minutos de conversa</label><input type="range" min="5" max="60" step="5" value={data.daily} onChange={(e) => update('daily', Number(e.target.value))} /><span className="hint">Comece pequeno. Consistência vale mais do que intensidade.</span></div>
        <div className="row between"><Button type="button" className="ghost" onClick={() => setStep(2)}>Voltar</Button><Button className="primary" disabled={loading}>{loading ? 'Criando conta…' : 'Criar conta e praticar'}</Button></div>
      </form>}
    </div>
    {testOpen && <div className="overlay"><div className="modal quick-test"><div className="row between"><div><h2>Teste rápido</h2><p className="small muted">Pergunta {testIndex + 1} de {TEST_QUESTIONS.length}</p></div><Button className="ghost sm" onClick={() => setTestOpen(false)}>✕</Button></div><div className="bar" style={{ margin: '16px 0 20px' }}><span style={{ width: `${((testIndex + 1) / TEST_QUESTIONS.length) * 100}%` }} /></div><h3>{TEST_QUESTIONS[testIndex].prompt}</h3><div className="test-options">{TEST_QUESTIONS[testIndex].options.map((option) => <Button key={option} className="block" onClick={() => answerTest(option)}>{option}</Button>)}</div><Button className="ghost block" onClick={() => setTestOpen(false)}>Cancelar teste</Button></div></div>}
  </AuthShell>
}

function Topbar({ user, screen, setScreen, stats, onLogout }) {
  const nav = [['home', 'Início'], ['review', `Vocabulário${stats?.totals?.words ? ` · ${stats.totals.words}` : ''}`], ['progress', 'Progresso'], ['profile', 'Perfil']]
  return <header className="topbar">
    <Brand />
    <nav className="nav">{nav.map(([id, label]) => <button key={id} aria-current={screen === id} onClick={() => setScreen(id)}>{label}</button>)}</nav>
    <div className="chips"><Chip>🔥 {user?.streak || 0}</Chip><Chip className="accent mono">{user?.xp || 0} XP</Chip></div>
    <button className="mobile-logout" onClick={onLogout} aria-label="Sair">↪</button>
  </header>
}

function HomeScreen({ user, stats, curriculum, onStart, onScreen }) {
  const lessons = curriculum?.units?.flatMap((unit) => unit.lessons) || []
  const next = lessons.find((lesson) => lesson.status !== 'completed') || lessons[0]
  const goal = stats?.daily_goal_min || user?.daily_goal_min || 15
  const minutes = stats?.today?.minutes || 0
  return <>
    <div className="grid hero home-hero">
      <section className="card stack">
        <div>
          <span className="tiny muted eyebrow">{greeting().toUpperCase()}</span>
          <h1>{greeting()}, {firstName(user?.name)}! Ready to talk?</h1>
          <p className="muted small">Você está a {Math.max(0, goal - minutes)} minuto(s) de bater a meta de hoje. Fale em voz alta — a pronúncia treina junto.</p>
        </div>
        <div className="row wrap">
          <Chip>🔥 {user?.streak || 0} dias em sequência</Chip>
          <Chip>🎯 Nível {user?.cefr_level || 'A1'}</Chip>
          <button className="chip accent chip-button" onClick={() => onScreen('review')}>🔁 {stats?.totals?.due_vocab || 0} palavra(s) para revisar</button>
        </div>
        <div className="row home-actions"><Button className="accent" onClick={() => onStart(next)}>▶ Continuar conversando</Button><Button onClick={() => next && onStart(next)}>Ver a lição</Button></div>
        <ProgressRing value={minutes} total={goal} />
      </section>
      <aside className="col">
        <div className="card next-card">
          <div className="row between"><h3>Próxima lição</h3><Chip className="flat">{next?.level || user?.cefr_level || 'A1'}</Chip></div>
          <h3 className="lesson-title">{next?.title || 'Comece sua primeira conversa'}</h3>
          <p className="small muted">{next?.scenario || 'Escolha um cenário e pratique no seu ritmo.'}</p>
          {next?.focus && <span className="focus-tag">foco: {next.focus}</span>}
          <Button className="primary block" style={{ marginTop: 14 }} onClick={() => onStart(next)}>{next ? 'Praticar agora' : 'Escolher uma lição'}</Button>
        </div>
        <div className="card">
          <h3>Conversa livre</h3>
          <p className="small muted" style={{ marginTop: 6 }}>Sem roteiro: escolha um tema e o tutor conduz a conversa no seu nível.</p>
          <select className="select" style={{ marginTop: 12 }} defaultValue="Your perfect weekend in your city"><option>Your perfect weekend in your city</option><option>A decision that changed your career</option><option>Technology you would ban tomorrow</option><option>The best advice you ever received</option></select>
          <Button className="block" style={{ marginTop: 10 }} onClick={() => onStart(null)}>Falar sobre isso</Button>
        </div>
      </aside>
    </div>
    <div className="curriculum-heading"><h2>Trilha de conversas</h2><p className="small muted">Lições guiadas por cenário, do seu nível ao próximo desafio.</p></div>
    {curriculum?.units?.map((unit) => <section className="unit" key={unit.unit}><div className="unit-head"><h2>{unit.unit}</h2><Chip className="flat">{unit.level}</Chip></div><div className="grid cols-2">{unit.lessons.map((lesson) => <button key={lesson.id} className={cx('lesson', lesson.status === 'completed' && 'done')} onClick={() => onStart(lesson)}><span className="badge">{lesson.status === 'completed' ? '✓' : lesson.level}</span><span style={{ flex: 1 }}><span className="t" style={{ display: 'block' }}>{lesson.title}</span><span className="s" style={{ display: 'block' }}>{lesson.scenario}</span><span className="f">foco: {lesson.focus}</span></span>{lesson.best_score && <span className="small muted">{lesson.best_score}</span>}</button>)}</div></section>)}
  </>
}

function Message({ message, onSpeak, onSaveVocab, savedTerms }) {
  if (message.role === 'user') return <div className="msg me fade"><span className="avatar">EU</span><div className="bubble-text">{message.content}</div></div>
  const correction = message.payload?.correction
  const vocab = message.payload?.vocab || []
  return <div className="msg fade"><span className="avatar">AI</span><div style={{ minWidth: 0 }}>
    <div className="bubble-text">{message.content}</div>
    {correction?.has_error && message.forUser && <div className="card-fix"><div className="strike">{message.forUser}</div><div className="ok">✓ {correction.corrected}</div><div className="why">{correction.explanation}</div><Button className="sm" style={{ marginTop: 8 }} onClick={() => onSpeak(correction.corrected)}>🔈 ouvir a versão correta</Button></div>}
    {vocab.length > 0 && <div className="vocab-chips">{vocab.map((item) => <span className="vocab-chip" key={item.term}><button onClick={() => onSpeak(item.term)}>🔈</button><span>{item.term}{item.meaning ? ` · ${item.meaning}` : ''}</span><button onClick={() => onSaveVocab(item)} title="Salvar palavra">{savedTerms.has(item.term) ? '✓' : '＋'}</button></span>)}</div>}
    <div className="row" style={{ marginTop: 6 }}><Button className="ghost sm" onClick={() => onSpeak(message.content)}>🔈 ouvir</Button></div>
  </div></div>
}

function TalkScreen({ talk, user, vocab, onSend, onEnd, onSpeak, onSaveVocab, onToggleMic, onToggleVoice, setDraft }) {
  const savedTerms = new Set(vocab.map((item) => item.term))
  const lesson = talk.lesson
  return <div className="grid talk">
    <section className="chat">
      <header className="chat-head">
        <Button className="ghost sm" onClick={onEnd}>← Sair</Button>
        <div style={{ flex: 1, minWidth: 0 }}><div style={{ fontWeight: 620 }}>{lesson?.title || 'Conversa livre'}</div><div className="tiny muted">{lesson?.scenario || 'Tema aberto escolhido por você'} · {lesson?.level || user?.cefr_level}</div></div>
        <button className={cx('chip', 'voice-toggle', talk.voiceMode && 'accent')} onClick={onToggleVoice} aria-pressed={talk.voiceMode}>🎙 voz {talk.voiceMode ? 'on' : 'off'}</button><Button className="sm" onClick={onEnd}>Encerrar</Button>
      </header>
      <div className="chat-body" id="chatBody">{talk.messages.map((message, index) => <Message key={`${message.created_at || index}-${index}`} message={message} onSpeak={onSpeak} onSaveVocab={onSaveVocab} savedTerms={savedTerms} />)}{talk.loading && <div className="msg fade"><span className="avatar">AI</span><div className="bubble-text typing"><i /><i /><i /></div></div>}</div>
      <footer className="chat-foot">
        {talk.hint && <div className="row" style={{ marginBottom: 8 }}><Chip className="accent">💡 {talk.hint}</Chip></div>}
        <div className="voice-status"><span className={cx('voice-dot', talk.listening && 'live', talk.loading && 'thinking')} />{talk.loading ? 'Alex está respondendo…' : talk.listening ? 'Estou ouvindo — fale em inglês' : talk.voiceMode ? 'Toque no microfone; sua resposta será enviada automaticamente' : 'Modo texto: escreva ou use o microfone'}</div><div className="mic-row"><button className={cx('mic', talk.listening && 'live')} onClick={onToggleMic} title={sttSupported() ? 'Falar em inglês' : 'Reconhecimento de fala indisponível'}>{talk.listening ? '⏹' : '🎙'}</button><textarea className="textarea" rows="1" placeholder={talk.listening ? 'Estou ouvindo…' : 'Escreva em inglês (ex.: I have 30 years)'} value={talk.draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); onSend() } }} /><Button className="primary" onClick={onSend} disabled={talk.loading || !talk.draft.trim()}>Enviar</Button></div>
      </footer>
    </section>
    <aside className="col">
      <div className="card"><div className="row between"><h3>Sessão</h3><Chip className="flat">{talk.turn} respostas</Chip></div><div className="grid cols-2" style={{ marginTop: 12 }}><div><div className="tiny muted">XP hoje</div><div className="mono stat-number">+{talk.xp}</div></div><div><div className="tiny muted">Palavras salvas</div><div className="mono stat-number">{vocab.length}</div></div></div><Button className="block" style={{ marginTop: 12 }} onClick={onEnd}>Encerrar e ver relatório</Button></div>
      {lesson && <><div className="card"><h3>Objetivos da lição</h3><ul className="small objective-list">{lesson.objectives.map((objective) => <li key={objective}>{objective}</li>)}</ul><p className="tiny muted" style={{ marginTop: 10 }}>Foco gramatical: {lesson.focus}</p></div><div className="card"><div className="row between"><h3>Frases-alvo</h3><span className="tiny muted">toque para ouvir</span></div><div className="phrase-list">{lesson.phrases.map(([english, portuguese]) => <div className="phrase" key={english}><Button className="ghost sm" onClick={() => onSpeak(english)}>🔈</Button><div style={{ flex: 1 }}><div className="small strong">{english}</div><div className="tiny muted">{portuguese}</div></div><button className="chip flat" onClick={() => onSaveVocab({ term: english, meaning: portuguese })}>{savedTerms.has(english) ? '✓' : '+'}</button></div>)}</div></div></>}
    </aside>
  </div>
}

function ReportModal({ report, onClose, onNext }) {
  if (!report) return null
  const summary = report.summary || report
  return <div className="overlay"><div className="modal report-modal fade"><div className="row between" style={{ marginBottom: 14 }}><h2>Relatório da sessão</h2><Button className="ghost sm" onClick={onClose}>✕</Button></div><div className="grid report-grid"><div className="card tight"><div className="tiny muted">Nota da sessão</div><div className="mono report-number">{summary.score}</div></div><div className="card tight"><div className="tiny muted">Respostas</div><div className="mono report-number">{summary.student_turns || summary.turns}</div></div><div className="card tight"><div className="tiny muted">XP ganho</div><div className="mono report-number">+{summary.xp_awarded || summary.xp}</div></div></div><div className="grid report-grid secondary"><div className="card tight"><div className="tiny muted">Palavras faladas</div><div className="mono">{summary.words_spoken || summary.words}</div></div><div className="card tight"><div className="tiny muted">Correções</div><div className="mono">{summary.corrections}</div></div><div className="card tight"><div className="tiny muted">Duração</div><div className="mono">~{summary.duration_min || summary.min} min</div></div></div><p className="small muted" style={{ marginTop: 14 }}>Sequência atual: <b>{report.streak?.streak || report.streak || 1} dia(s)</b> · recorde: <b>{report.streak?.best || report.best || 1} dias</b>.</p><div className="row report-actions"><Button onClick={onClose}>Fechar</Button><Button className="ghost" onClick={onClose}>Início</Button>{report.next_lesson && <Button className="primary next-button" onClick={() => onNext(report.next_lesson)}>Próxima: {report.next_lesson.title}</Button>}</div></div></div>
}

function ReviewScreen({ items, onReview, onDelete, onAdd }) {
  const [index, setIndex] = useState(0)
  const [revealed, setRevealed] = useState(false)
  const [correct, setCorrect] = useState(0)
  const [wrong, setWrong] = useState(0)
  const current = items[index % Math.max(items.length, 1)]
  useEffect(() => { if (index >= items.length && items.length) setIndex(0) }, [index, items.length])
  if (!items.length) return <div className="card empty-state"><h3>Nenhuma palavra salva ainda</h3><p className="small muted" style={{ marginTop: 6 }}>Durante a conversa, toque no <b>＋</b> das sugestões do tutor para guardar palavras aqui.</p><Button style={{ marginTop: 16 }} onClick={onAdd}>Ir para uma conversa</Button></div>
  async function answer(value) {
    await onReview(current.id, value)
    if (value) setCorrect((number) => number + 1)
    else setWrong((number) => number + 1)
    setIndex((number) => number + 1)
    setRevealed(false)
  }
  return <><div className="page-heading"><div><h1>Vocabulário</h1><p className="muted small">Repetição espaçada: cada acerto empurra a palavra para mais longe (1 → 2 → 4 → 8 → 16 → 32 dias).</p></div><Button onClick={onAdd}>＋ Adicionar palavra</Button></div><div className="row review-tabs"><Chip className="accent">Para hoje · {items.filter((item) => item.due).length}</Chip><Chip>Todas · {items.length}</Chip></div><div className="grid cols-2 review-layout"><div className="col"><div className={cx('flash', revealed && 'back')}><div><div className="term">{current.term}</div>{revealed && <><p className="meaning">{current.meaning || 'Sem significado cadastrado'}</p>{current.example && <p className="small muted">{current.example}</p>}</>}{!revealed ? <p className="tiny muted" style={{ marginTop: 8 }}>Você lembra o significado? Toque para revelar.</p> : <p className="tiny muted" style={{ marginTop: 8 }}>caixa {(current.box || 0) + 1} de 6 · {current.correct || 0} acerto(s)</p>}</div><div className="row"><Button className="sm" onClick={() => speak(current.term)}>🔈 ouvir</Button>{!revealed && <Button className="sm primary" onClick={() => setRevealed(true)}>Revelar</Button>}</div></div>{revealed ? <div className="row"><Button className="block" onClick={() => answer(false)}>😅 Não lembrei</Button><Button className="accent block" onClick={() => answer(true)}>✅ Lembrei</Button></div> : <Button className="block" onClick={() => setRevealed(true)}>Mostrar resposta</Button>}<div className="card tight"><div className="row between"><span className="tiny muted">Sessão</span><span className="tiny mono">{correct} acertos · {wrong} erros</span></div><div className="bar" style={{ marginTop: 8 }}><span style={{ width: `${((index % items.length) + 1) / items.length * 100}%` }} /></div><p className="tiny muted" style={{ marginTop: 7 }}>Item {index % items.length + 1} de {items.length}</p></div></div><div className="card vocab-table-card"><div className="row between"><h3>Todas as palavras</h3><span className="tiny muted">{items.length} itens</span></div><table style={{ marginTop: 10 }}><thead><tr><th>Termo</th><th>Significado</th><th /></tr></thead><tbody>{items.map((item) => <tr key={item.id}><td><button className="table-term" onClick={() => speak(item.term)}>🔈 <b>{item.term}</b>{item.due && <Chip className="accent tiny">hoje</Chip>}</button></td><td className="small muted">{item.meaning || '—'}</td><td><button className="delete-button" onClick={() => onDelete(item.id)} aria-label={`Excluir ${item.term}`}>🗑️</button></td></tr>)}</tbody></table></div></div></>
}

function ProgressScreen({ stats, curriculum, history }) {
  const maxXp = Math.max(220, ...(stats?.last7 || []).map((item) => item.xp || 0))
  return <><div className="page-heading"><div><h1>Seu progresso</h1><p className="muted small">Acompanhe consistência, produção oral e evolução por lição.</p></div></div><div className="grid cols-4 stat-grid"><Stat label="XP total" value={stats?.xp || 0} note={`Nível ${stats?.level || 'A1'}`} /><Stat label="Sequência" value={`${stats?.streak || 0} d`} note={`melhor: ${stats?.best_streak || 0} dias`} /><Stat label="Conversas" value={stats?.totals?.conversations || 0} note={`${stats?.totals?.turns || 0} respostas suas`} /><Stat label="Palavras" value={stats?.totals?.words || 0} note={`${stats?.totals?.due_vocab || 0} para revisar hoje`} /></div><div className="grid cols-2 progress-top"><div className="card"><div className="row between"><h3>Últimos 7 dias</h3><Chip>{(stats?.last7 || []).reduce((sum, item) => sum + (item.minutes || 0), 0)} min de conversa</Chip></div><div className="chart">{(stats?.last7 || []).map((item) => <div className="col-b" key={item.day}><span className="tiny muted">{item.xp || ''}</span><div className={cx('b', item.xp > 0 && 'on')} style={{ height: `${Math.max(4, ((item.xp || 0) / maxXp) * 84)}px` }} /><span className="tiny muted">{item.day.slice(8)}</span></div>)}</div><p className="tiny muted" style={{ marginTop: 8 }}>Meta diária: {stats?.daily_goal_min || 15} minutos. Barras cheias = dias com atividade.</p></div><div className="card"><h3>Trilha por nível</h3><div className="trail-list">{['A1', 'A2', 'B1', 'B2'].map((level) => { const lessons = curriculum?.units?.flatMap((unit) => unit.lessons).filter((lesson) => lesson.level === level) || []; const done = lessons.filter((lesson) => lesson.status === 'completed').length; return <div key={level}><div className="row between"><b className="small">{level}{level === stats?.level ? ' · seu nível' : ''}</b><span className="tiny muted">{done}/{lessons.length} lições concluídas</span></div><div className="bar"><span style={{ width: `${lessons.length ? done / lessons.length * 100 : 0}%` }} /></div></div> })}</div><p className="tiny muted" style={{ marginTop: 14 }}>Concluir lições do seu nível e do nível seguinte é o caminho mais rápido para subir de faixa.</p></div></div><div className="card history-card"><div className="row between"><h3>Histórico de conversas</h3><span className="tiny muted">últimas 50 sessões</span></div>{history.length ? <div className="table-scroll"><table style={{ marginTop: 10 }}><thead><tr><th>Conversa</th><th>Nível</th><th>Respostas</th><th>Nota</th><th>XP</th><th>Quando</th></tr></thead><tbody>{history.map((item) => <tr key={item.id}><td><b>{item.title}</b></td><td>{item.level}</td><td>{item.student_turns || item.turns}</td><td>{item.score ?? '—'}</td><td>{item.xp}</td><td className="small muted">{formatDate(item.started_at)}</td></tr>)}</tbody></table></div> : <p className="small muted" style={{ marginTop: 8 }}>Nenhuma conversa concluída ainda.</p>}</div></>
}

function Stat({ label, value, note }) {
  return <div className="card tight stat-card"><div className="tiny muted uppercase">{label}</div><div className="stat-value mono">{value}</div><div className="tiny muted">{note}</div></div>
}

function ProfileScreen({ user, onUser, onToast }) {
  const [form, setForm] = useState({ name: user.name, level: user.cefr_level, goal: user.goal, daily: user.daily_goal_min, voice: user.tts_voice || 'nova' })
  const [provider, setProvider] = useState(user.ai_provider || 'openai')
  const [apiKey, setApiKey] = useState('')
  const [saving, setSaving] = useState(false)
  const [keySaving, setKeySaving] = useState(false)
  useEffect(() => setForm({ name: user.name, level: user.cefr_level, goal: user.goal, daily: user.daily_goal_min, voice: user.tts_voice || 'nova' }), [user])
  async function saveProfile(event) {
    event.preventDefault(); setSaving(true)
    try { const result = await patch('/me', { name: form.name, cefr_level: form.level, goal: form.goal, daily_goal_min: Number(form.daily), tts_voice: form.voice }); onUser(result.user); onToast('Perfil salvo.') } catch (err) { onToast(err.message, 'error') } finally { setSaving(false) }
  }
  async function saveKey(event) {
    event.preventDefault(); if (!apiKey.trim()) return onToast('Informe a chave de API.', 'error'); setKeySaving(true)
    try { const result = await put('/me/ai-key', { provider, api_key: apiKey }); onUser(result.user); setApiKey(''); onToast('Chave salva e criptografada.') } catch (err) { onToast(err.message, 'error') } finally { setKeySaving(false) }
  }
  return <><div className="page-heading"><div><h1>Perfil e configurações</h1><p className="muted small">Ajuste nível, meta, voz e conecte sua própria chave de IA.</p></div><Button onClick={() => { setToken(null); window.location.reload() }}>Sair da conta</Button></div><div className="grid cols-4 stat-grid"><Stat label="Plano" value="Free" note="dados no seu servidor" /><Stat label="XP" value={user.xp} note="conversas salvas" /><Stat label="Sequência" value={`${user.streak} d`} note={`recorde ${user.best_streak} dias`} /><Stat label="IA ativa" value={user.has_key ? 'Conectada' : 'Demonstração'} note={user.has_key ? user.ai_provider : 'modo sem chave'} /></div><div className="grid cols-2 profile-layout"><form className="card stack" onSubmit={saveProfile}><h3>Perfil de aprendiz</h3><div className="field"><label>Nome</label><input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div><div className="field"><label>Nível (CEFR)</label><select className="select" value={form.level} onChange={(e) => setForm({ ...form, level: e.target.value })}>{LEVELS.map((level) => <option key={level.id} value={level.id}>{level.id} · {level.short}</option>)}</select><span className="hint">A trilha mostra as lições do seu nível e do nível seguinte.</span></div><div className="field"><label>Objetivo principal</label><select className="select" value={form.goal} onChange={(e) => setForm({ ...form, goal: e.target.value })}>{GOALS.map((goal) => <option key={goal.id} value={goal.id}>{goal.label}</option>)}</select></div><div className="field"><label>Meta diária: {form.daily} min</label><input type="range" min="5" max="60" step="5" value={form.daily} onChange={(e) => setForm({ ...form, daily: e.target.value })} /></div><div className="field"><label>Voz do tutor</label><select className="select" value={form.voice} onChange={(e) => setForm({ ...form, voice: e.target.value })}><option value="nova">Nova</option><option value="alloy">Alloy</option><option value="echo">Echo</option><option value="fable">Fable</option></select><span className="hint">Com chave OpenAI/ElevenLabs a voz é neural. Sem chave, usamos a voz do navegador.</span></div><Button className="primary" disabled={saving}>{saving ? 'Salvando…' : 'Salvar perfil'}</Button></form><div className="col"><form className="card stack" onSubmit={saveKey}><div className="row between"><h3>Motor de IA</h3><Chip className="flat">{user.has_key ? 'chave salva' : 'sem chave'}</Chip></div><p className="small muted">O Fluenta funciona em modo demonstração sem chave. Para conversas realmente geradas por IA e voz neural, conecte a chave aqui.</p><div className="field"><label>Provedor</label><select className="select" value={provider} onChange={(e) => setProvider(e.target.value)}><option value="openai">OpenAI (GPT-4o mini + voz neural)</option><option value="gemini">Google Gemini</option><option value="anthropic">Anthropic Claude</option><option value="openrouter">OpenRouter</option></select></div><div className="field"><label>Chave de API</label><input className="input" type="password" placeholder={user.has_key ? '•••••••••••• (substituir)' : 'sk-… (fica só neste servidor)'} value={apiKey} onChange={(e) => setApiKey(e.target.value)} /></div><Button className="primary" disabled={keySaving}>{keySaving ? 'Salvando…' : 'Salvar chave'}</Button></form><div className="card"><h3>Como está montado</h3><ul className="small muted setup-list"><li>Front-end React + Vite, back-end Express e banco SQLite.</li><li>Conversa, correções e vocabulário são salvos por usuário.</li><li>Voz: reconhecimento de fala do navegador; narração neural quando há chave.</li><li>XP, sequência diária e repetição espaçada em caixas de 1 a 32 dias.</li></ul></div></div></div></>
}

function App() {
  const [booting, setBooting] = useState(true)
  const [user, setUser] = useState(null)
  const [auth, setAuth] = useState('welcome')
  const [screen, setScreen] = useState('home')
  const [stats, setStats] = useState(null)
  const [curriculum, setCurriculum] = useState(null)
  const [vocab, setVocab] = useState([])
  const [history, setHistory] = useState([])
  const [talk, setTalk] = useState(null)
  const [report, setReport] = useState(null)
  const [toast, setToast] = useState(null)
  const recognizerRef = useRef(null)
  const talkRef = useRef(null)
  useEffect(() => { talkRef.current = talk }, [talk])

  function showToast(message, type = 'ok') {
    setToast({ message, type })
    window.setTimeout(() => setToast(null), 3200)
  }

  async function refreshData() {
    const [curriculumData, statsData, vocabData, historyData] = await Promise.all([api('/curriculum'), api('/stats'), api('/vocab'), api('/conv')])
    setCurriculum(curriculumData)
    setStats(statsData)
    setVocab(vocabData.items || [])
    setHistory(historyData.conversations || [])
  }

  async function enterApp(nextUser) {
    setUser(nextUser)
    setAuth(null)
    try { await refreshData() } catch (err) { showToast(err.message, 'error') }
    setBooting(false)
  }

  useEffect(() => {
    let cancelled = false
    async function boot() {
      if (!getToken()) { if (!cancelled) setBooting(false); return }
      try { const result = await api('/me'); if (!cancelled) await enterApp(result.user) } catch { setToken(null); if (!cancelled) setBooting(false) }
    }
    boot()
    return () => { cancelled = true }
  }, [])

  useEffect(() => () => { recognizerRef.current?.abort(); stopSpeaking() }, [])

  useEffect(() => {
    function handleShortcut(event) {
      if (event.ctrlKey && event.code === 'Space' && talkRef.current) {
        event.preventDefault()
        toggleMic()
      }
    }
    window.addEventListener('keydown', handleShortcut)
    return () => window.removeEventListener('keydown', handleShortcut)
  })

  async function startLesson(lesson) {
    try {
      const result = await post('/conv/start', { lesson_id: lesson?.id || null, level: lesson?.level || user?.cefr_level })
      setTalk({ id: result.conversation.id, lesson: result.lesson, messages: result.messages, turn: 0, xp: 0, draft: '', hint: '', loading: false, listening: false, voiceMode: true })
      setScreen('talk')
      const opener = result.messages?.[0]?.content
      if (opener) speak(opener)
    } catch (err) { showToast(err.message, 'error') }
  }

  async function sendMessage(textOverride = '') {
    const currentTalk = talkRef.current
    const content = String(textOverride || currentTalk?.draft || '').trim()
    if (!currentTalk || !content || currentTalk.loading) return
    if (recognizerRef.current) recognizerRef.current.cancelled = true
    recognizerRef.current?.abort()
    recognizerRef.current = null
    setTalk((current) => ({ ...current, draft: '', listening: false, loading: true, messages: [...current.messages, { role: 'user', content }] }))
    try {
      const result = await post(`/conv/${currentTalk.id}/message`, { content })
      const message = { ...result.message, forUser: content }
      setTalk((current) => ({ ...current, messages: [...current.messages, message], turn: current.turn + 1, xp: current.xp + (result.xp_awarded || 0), hint: result.message.payload?.hint || '', loading: false }))
      setUser((current) => ({ ...current, xp: (current?.xp || 0) + (result.xp_awarded || 0), streak: result.streak?.streak || current?.streak }))
      await speak(result.message.content)
      const [statsData, vocabData] = await Promise.all([api('/stats'), api('/vocab')])
      setStats(statsData); setVocab(vocabData.items || [])
      if (talkRef.current?.voiceMode) window.setTimeout(startVoiceRecognition, 260)
    } catch (err) {
      setTalk((current) => ({ ...current, loading: false }))
      showToast(err.message, 'error')
    }
  }

  async function endConversation() {
    if (recognizerRef.current) recognizerRef.current.cancelled = true
    recognizerRef.current?.abort()
    recognizerRef.current = null
    if (!talk) return
    if (!talk.turn) { setTalk(null); setScreen('home'); return }
    try {
      const result = await post(`/conv/${talk.id}/end`, {})
      setReport(result)
      setTalk(null)
      setScreen('home')
      await refreshData()
    } catch (err) { showToast(err.message, 'error') }
  }

  async function saveVocab(item) {
    try { await post('/vocab', { term: item.term, meaning: item.meaning || '', example: item.example || '', lesson_id: talk?.lesson?.id || null }); const data = await api('/vocab'); setVocab(data.items || []); showToast('Palavra salva para revisar.') } catch (err) { showToast(err.message, 'error') }
  }

  async function reviewVocab(id, correct) {
    try { await post(`/vocab/${id}/review`, { correct }); const data = await api('/vocab'); setVocab(data.items || []); const stat = await api('/stats'); setStats(stat) } catch (err) { showToast(err.message, 'error') }
  }

  async function deleteVocab(id) {
    try { await del(`/vocab/${id}`); setVocab((items) => items.filter((item) => item.id !== id)); showToast('Palavra removida.') } catch (err) { showToast(err.message, 'error') }
  }

  function startVoiceRecognition() {
    const currentTalk = talkRef.current
    if (!currentTalk || !currentTalk.voiceMode || currentTalk.loading || recognizerRef.current || !sttSupported()) return
    const recognizer = createRecognizer({
      onPartial: (text) => setTalk((current) => current ? { ...current, draft: text } : current),
      onEnd: (text) => {
        const wasCancelled = recognizer.cancelled
        recognizerRef.current = null
        setTalk((current) => current ? { ...current, listening: false, draft: text || current.draft } : current)
        if (!wasCancelled && text?.trim() && talkRef.current?.voiceMode) sendMessage(text)
      },
      onError: (reason) => {
        recognizerRef.current = null
        setTalk((current) => current ? { ...current, listening: false } : current)
        if (reason !== 'aborted') showToast(reason === 'permission' ? 'Permita o uso do microfone para falar.' : 'Não consegui ouvir. Tente novamente.', 'error')
      },
    })
    recognizerRef.current = recognizer
    setTalk((current) => current ? { ...current, listening: true, draft: '' } : current)
    recognizer.start()
  }

  function toggleMic() {
    if (!talkRef.current) return
    if (talkRef.current.listening) { recognizerRef.current?.stop(); return }
    if (!sttSupported()) { showToast('Reconhecimento de fala não está disponível neste navegador.', 'error'); return }
    if (!talkRef.current.voiceMode) {
      setTalk((current) => ({ ...current, voiceMode: true }))
      window.setTimeout(startVoiceRecognition, 0)
      return
    }
    startVoiceRecognition()
  }

  function toggleVoice() {
    const enabled = !Boolean(talkRef.current?.voiceMode)
    if (!enabled) {
      if (recognizerRef.current) recognizerRef.current.cancelled = true
      recognizerRef.current?.abort()
      recognizerRef.current = null
      setTalk((current) => current ? { ...current, voiceMode: false, listening: false } : current)
      return
    }
    setTalk((current) => current ? { ...current, voiceMode: true } : current)
    showToast('Voz ativada. Toque no microfone para falar.')
  }

  async function logout() {
    try { await post('/auth/logout', {}) } catch {}
    setToken(null); setUser(null); setTalk(null); setAuth('welcome'); setScreen('home')
  }

  function handleUser(nextUser) { setUser(nextUser); refreshData().catch(() => {}) }

  if (booting) return <div className="loading-screen"><div className="loading-mark">F</div><span>Carregando seu espaço de prática…</span></div>
  if (!user && auth === 'welcome') return <WelcomeScreen onRegister={() => setAuth('register')} onLogin={() => setAuth('login')} />
  if (!user && auth === 'login') return <LoginScreen onBack={() => setAuth('welcome')} onLoggedIn={enterApp} />
  if (!user && auth === 'register') return <RegisterScreen onBack={() => setAuth('welcome')} onRegistered={enterApp} />

  return <div className="app"><Topbar user={user} screen={screen} setScreen={setScreen} stats={stats} onLogout={logout} /><main className={cx('main', screen === 'talk' && 'wide')}>
    {screen === 'home' && <HomeScreen user={user} stats={stats} curriculum={curriculum} onStart={startLesson} onScreen={setScreen} />}
    {screen === 'talk' && talk && <TalkScreen talk={talk} user={user} vocab={vocab} onSend={sendMessage} onEnd={endConversation} onSpeak={speak} onSaveVocab={saveVocab} onToggleMic={toggleMic} onToggleVoice={toggleVoice} setDraft={(draft) => setTalk((current) => ({ ...current, draft }))} />}
    {screen === 'review' && <ReviewScreen items={vocab} onReview={reviewVocab} onDelete={deleteVocab} onAdd={() => { setScreen('home'); showToast('Escolha uma lição para encontrar palavras novas.') }} />}
    {screen === 'progress' && <ProgressScreen stats={stats} curriculum={curriculum} history={history} />}
    {screen === 'profile' && <ProfileScreen user={user} onUser={handleUser} onToast={showToast} />}
  </main><ReportModal report={report} onClose={() => setReport(null)} onNext={(lesson) => { setReport(null); startLesson(lesson) }} />{toast && <div className={cx('toast', toast.type === 'error' && 'toast-error')}>{toast.message}</div>}</div>
}

createRoot(document.getElementById('root')).render(<App />)
