# Fluenta offline

Abra `index.html` diretamente no navegador ou publique esta pasta em qualquer hospedagem estática.

A demo roda sem servidor, sem chave de IA e sem dependências externas. O progresso fica apenas na memória da página.
