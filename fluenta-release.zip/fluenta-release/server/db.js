import Database from 'better-sqlite3'
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), 'data')
fs.mkdirSync(DATA_DIR, { recursive: true })

export const db = new Database(path.join(DATA_DIR, 'fluenta.db'))
db.pragma('journal_mode = WAL')
db.pragma('foreign_keys = ON')

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  cefr_level TEXT NOT NULL DEFAULT 'A1',
  goal TEXT NOT NULL DEFAULT 'conversacao',
  daily_goal_min INTEGER NOT NULL DEFAULT 15,
  ui_lang TEXT NOT NULL DEFAULT 'pt-BR',
  tts_voice TEXT NOT NULL DEFAULT 'nova',
  ai_provider TEXT,
  ai_key_enc TEXT,
  xp INTEGER NOT NULL DEFAULT 0,
  streak INTEGER NOT NULL DEFAULT 0,
  best_streak INTEGER NOT NULL DEFAULT 0,
  last_active_day TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS auth_sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS conversations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id TEXT,
  title TEXT NOT NULL,
  level TEXT NOT NULL,
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  ended_at TEXT,
  xp INTEGER NOT NULL DEFAULT 0,
  turns INTEGER NOT NULL DEFAULT 0,
  score INTEGER
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  payload TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS vocab (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  term TEXT NOT NULL,
  meaning TEXT,
  example TEXT,
  lesson_id TEXT,
  box INTEGER NOT NULL DEFAULT 0,
  due_day TEXT NOT NULL,
  reviews INTEGER NOT NULL DEFAULT 0,
  correct INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (user_id, term)
);

CREATE TABLE IF NOT EXISTS lesson_progress (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'in_progress',
  attempts INTEGER NOT NULL DEFAULT 0,
  best_score INTEGER,
  last_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, lesson_id)
);

CREATE TABLE IF NOT EXISTS daily_stats (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day TEXT NOT NULL,
  xp INTEGER NOT NULL DEFAULT 0,
  turns INTEGER NOT NULL DEFAULT 0,
  seconds INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day)
);

CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_vocab_user ON vocab(user_id, due_day);
`)

/* ---------------------------------- utils --------------------------------- */

export const today = () => new Date().toISOString().slice(0, 10)

export function dayOffset(days) {
  const d = new Date()
  d.setDate(d.getDate() + days)
  return d.toISOString().slice(0, 10)
}

function secret() {
  if (process.env.SERVER_SECRET) return process.env.SERVER_SECRET
  const p = path.join(DATA_DIR, '.secret')
  if (!fs.existsSync(p)) fs.writeFileSync(p, crypto.randomBytes(32).toString('hex'), { mode: 0o600 })
  return fs.readFileSync(p, 'utf8').trim()
}

/** Criptografa a chave de API do usuário em repouso (AES-256-GCM). */
export function encrypt(text) {
  const iv = crypto.randomBytes(12)
  const key = crypto.createHash('sha256').update(secret()).digest()
  const c = crypto.createCipheriv('aes-256-gcm', key, iv)
  const enc = Buffer.concat([c.update(text, 'utf8'), c.final()])
  return [iv.toString('base64'), c.getAuthTag().toString('base64'), enc.toString('base64')].join('.')
}

export function decrypt(payload) {
  try {
    const [ivB, tagB, dataB] = payload.split('.')
    const key = crypto.createHash('sha256').update(secret()).digest()
    const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivB, 'base64'))
    d.setAuthTag(Buffer.from(tagB, 'base64'))
    return Buffer.concat([d.update(Buffer.from(dataB, 'base64')), d.final()]).toString('utf8')
  } catch {
    return null
  }
}

/** Hash de senha com scrypt (sem dependências nativas). */
export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex')
  const hash = crypto.scryptSync(password, salt, 64).toString('hex')
  return `scrypt$${salt}$${hash}`
}

export function verifyPassword(password, stored) {
  try {
    const [, salt, hash] = stored.split('$')
    const test = crypto.scryptSync(password, salt, 64).toString('hex')
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(test, 'hex'))
  } catch {
    return false
  }
}

/* ------------------------------ regras de jogo ----------------------------- */

/** Atualiza streak com base no último dia ativo. Retorna { streak, best, isNewDay }. */
export function touchStreak(userId) {
  const user = db.prepare('SELECT streak, best_streak, last_active_day FROM users WHERE id = ?').get(userId)
  const t = today()
  if (user.last_active_day === t) return { streak: user.streak, best: user.best_streak, isNewDay: false }
  const yesterday = dayOffset(-1)
  const streak = user.last_active_day === yesterday ? user.streak + 1 : 1
  const best = Math.max(streak, user.best_streak)
  db.prepare('UPDATE users SET streak = ?, best_streak = ?, last_active_day = ? WHERE id = ?').run(streak, best, t, userId)
  return { streak, best, isNewDay: true }
}

export function addXp(userId, xp, { turns = 0, seconds = 0 } = {}) {
  if (xp) db.prepare('UPDATE users SET xp = xp + ? WHERE id = ?').run(xp, userId)
  db.prepare(
    `INSERT INTO daily_stats (user_id, day, xp, turns, seconds) VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(user_id, day) DO UPDATE SET xp = xp + excluded.xp, turns = turns + excluded.turns, seconds = seconds + excluded.seconds`
  ).run(userId, today(), xp, turns, seconds)
}
