/**
 * Popula uma conta de demonstração com histórico, vocabulário e progresso.
 * Uso: npm run seed:demo   →   login: demo@fluenta.app / demo1234
 */
import { db, hashPassword, dayOffset, today } from './db.js'
import { LESSONS } from './curriculum.js'

const EMAIL = 'demo@fluenta.app'
const PASSWORD = 'demo1234'

const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(EMAIL)
if (existing) {
  db.prepare('DELETE FROM users WHERE id = ?').run(existing.id)
  console.log('· conta demo anterior removida')
}

const info = db
  .prepare(
    `INSERT INTO users (name, email, password_hash, cefr_level, goal, daily_goal_min, xp, streak, best_streak, last_active_day)
     VALUES (?,?,?,?,?,?,?,?,?,?)`
  )
  .run('Ana Demo', EMAIL, hashPassword(PASSWORD), 'A2', 'carreira', 15, 940, 4, 9, today())
const userId = info.lastInsertRowid

const vocab = [
  ['to pull off', 'conseguir realizar algo difícil', 'We pulled it off at the last minute.', -1, 2],
  ['swamped', 'atolado(a) de trabalho', 'I’m swamped this week.', 0, 3],
  ['to touch base', 'dar um alô / alinhar rapidamente', 'Let’s touch base on Monday.', 0, 1],
  ['a fair point', 'um argumento justo', 'That’s a fair point.', 1, 4],
  ['to bring forward', 'antecipar (uma data)', 'If we bring the date forward, we drop testing.', 2, 1],
  ['to park something', 'deixar um assunto para depois', 'Can we park that for later?', 3, 2],
  ['gripping', 'envolvente, que prende', 'It’s gripping but a bit slow at first.', 5, 1],
  ['to be on the same page', 'estar alinhado', 'Let’s make sure we’re on the same page.', 0, 5],
]
for (const [term, meaning, example, dueIn, box] of vocab) {
  db.prepare(
    'INSERT INTO vocab (user_id, term, meaning, example, due_day, box, reviews, correct) VALUES (?,?,?,?,?,?,?,?)'
  ).run(userId, term, meaning, example, dayOffset(dueIn), box, box + 1, box)
}

const history = [
  ['a2-checkin', 9, 86, 118, -4],
  ['a2-weekend', 7, 74, 96, -3],
  ['b1-meeting', 11, 88, 140, -2],
  ['a2-job', 6, 71, 82, -1],
  ['a2-cafe', 10, 82, 126, 0],
]
for (const [lessonId, turns, score, xp, dayOffsetValue] of history) {
  const lesson = LESSONS.find((l) => l.id === lessonId)
  const row = db
    .prepare(
      `INSERT INTO conversations (user_id, lesson_id, title, level, started_at, ended_at, xp, turns, score)
       VALUES (?,?,?,?, datetime('now', ?), datetime('now', ?), ?, ?, ?)`
    )
    .run(userId, lessonId, lesson.title, lesson.level, `${dayOffsetValue} days`, `${dayOffsetValue} days`, xp, turns, score)
  db.prepare('INSERT INTO messages (conversation_id, role, content, payload) VALUES (?,?,?,?)').run(
    row.lastInsertRowid, 'tutor', lesson.opener, JSON.stringify({ correction: { has_error: false }, vocab: [], hint: '' })
  )
  for (let i = 0; i < turns; i++) {
    db.prepare('INSERT INTO messages (conversation_id, role, content) VALUES (?,?,?)').run(row.lastInsertRowid, 'user', 'Okay, that sounds good to me.')
    db.prepare('INSERT INTO messages (conversation_id, role, content, payload) VALUES (?,?,?,?)').run(
      row.lastInsertRowid, 'tutor', 'Nice! Tell me more about that.', JSON.stringify({ correction: { has_error: false }, vocab: [], hint: '' })
    )
  }
  db.prepare(
    `INSERT INTO lesson_progress (user_id, lesson_id, status, attempts, best_score, last_at) VALUES (?,?, 'completed', 1, ?, datetime('now', ?))
     ON CONFLICT(user_id, lesson_id) DO UPDATE SET status='completed', best_score=excluded.best_score`
  ).run(userId, lessonId, score, `${dayOffsetValue} days`)
}

for (let i = 6; i >= 0; i--) {
  const xp = [0, 120, 180, 0, 210, 160, 140][6 - i]
  const turns = xp ? Math.round(xp / 12) : 0
  const seconds = xp ? Math.round(xp * 3.2) : 0
  db.prepare('INSERT INTO daily_stats (user_id, day, xp, turns, seconds) VALUES (?,?,?,?,?)').run(userId, dayOffset(-i), xp, turns, seconds)
}

console.log(`✔ conta demo criada\n  e-mail: ${EMAIL}\n  senha:  ${PASSWORD}\n  vocabulário: ${vocab.length} itens · conversas: ${history.length}`)
