/**
 * Currículo de inglês — trilha por níveis CEFR.
 * Cada lição descreve um cenário de conversação, objetivos e chunks-alvo
 * que viram contexto do tutor de IA e itens de vocabulário do aluno.
 */

export const LEVELS = [
  { id: 'A1', label: 'A1 · Iniciante', blurb: 'Frases curtas do dia a dia, presente simples e vocabulário essencial.' },
  { id: 'A2', label: 'A2 · Básico', blurb: 'Conversas sociais, passado simples e situações previsíveis.' },
  { id: 'B1', label: 'B1 · Intermediário', blurb: 'Opiniões, narrativas e trabalho com mais autonomia.' },
  { id: 'B2', label: 'B2 · Intermediário avançado', blurb: 'Debate, nuance, linguagem diplomática e fluência natural.' },
]

export const GOALS = [
  { id: 'conversacao', label: 'Conversar sem travar' },
  { id: 'carreira', label: 'Carreira e reuniões' },
  { id: 'viagem', label: 'Viagens' },
  { id: 'exames', label: 'Provas e certificações' },
]

export const LESSONS = [
  /* ---------------------------------- A1 ---------------------------------- */
  {
    id: 'a1-hello', level: 'A1', unit: 'Unit 1 · First contacts', title: 'Say hello and introduce yourself',
    scenario: 'Meeting a new classmate at a language school', focus: 'verb to be (am/is/are), subject pronouns',
    objectives: ['Apresentar-se com nome, idade e cidade', 'Perguntar o nome da outra pessoa', 'Usar contrações (I’m, you’re)'],
    phrases: [['Hi, I’m Ana. Nice to meet you!', 'Oi, sou a Ana. Prazer em conhecer você!'], ['Where are you from?', 'De onde você é?'], ['I’m from Brazil, from São Paulo.', 'Sou do Brasil, de São Paulo.'], ['How old are you? I’m 28.', 'Quantos anos você tem? Tenho 28.']],
    opener: 'Hi! I’m Alex, your English tutor. We’re at a language school and I just sat next to you. Hi! What’s your name?',
  },
  {
    id: 'a1-spelling', level: 'A1', unit: 'Unit 1 · First contacts', title: 'Spell your name and give basic info',
    scenario: 'Registering at a gym reception', focus: 'alphabet, spelling, numbers 0-20, "Can you spell that?"',
    objectives: ['Soletrar o nome em inglês', 'Dar telefone e e-mail', 'Pedir repetição educadamente'],
    phrases: [['Can you spell that, please?', 'Você pode soletrar, por favor?'], ['It’s B-R-U-N-A.', 'É B-R-U-N-A.'], ['Sorry, could you repeat that?', 'Desculpe, pode repetir?'], ['My phone number is 11 9 8765-4321.', 'Meu telefone é 11 9 8765-4321.']],
    opener: 'Welcome to the gym! I’m Alex, the receptionist. I need to register you. What’s your full name, please?',
  },
  {
    id: 'a1-goodbye', level: 'A1', unit: 'Unit 1 · First contacts', title: 'Polite basics: please, thanks, goodbye',
    scenario: 'Leaving a friend’s place after coffee', focus: 'politeness formulas, imperatives, "thank you for…"',
    objectives: ['Agradecer e se despedir', 'Marcar um próximo encontro', 'Usar please/could em pedidos'],
    phrases: [['Thanks for the coffee!', 'Valeu pelo café!'], ['I have to go now.', 'Preciso ir agora.'], ['See you next week.', 'Até a próxima semana.'], ['Could you send me the address?', 'Você poderia me mandar o endereço?']],
    opener: 'Hey! Thanks for coming over. So, are you leaving already? Before you go — how was the coffee?',
  },
  {
    id: 'a1-routine', level: 'A1', unit: 'Unit 2 · Routine and numbers', title: 'Tell the time and describe your routine',
    scenario: 'Comparing daily routines with a coworker', focus: 'present simple, adverbs of frequency, telling the time',
    objectives: ['Falar horários e hábitos', 'Usar always/usually/never', 'Perguntar sobre a rotina do outro'],
    phrases: [['I usually wake up at 6:30.', 'Eu geralmente acordo às 6h30.'], ['What time do you have lunch?', 'A que horas você almoça?'], ['I never work out in the morning.', 'Eu nunca treino de manhã.'], ['After work, I go straight home.', 'Depois do trabalho, vou direto pra casa.']],
    opener: 'Morning! You look tired — rough start today? Tell me, what time did you wake up?',
  },
  {
    id: 'a1-shopping', level: 'A1', unit: 'Unit 2 · Routine and numbers', title: 'Numbers, prices and shopping',
    scenario: 'Buying shoes at a store', focus: 'how much, this/these, sizes, numbers over 20',
    objectives: ['Perguntar preços', 'Pedir tamanho e cor', 'Decidir compra e pagamento'],
    phrases: [['How much is this one?', 'Quanto custa este?'], ['Do you have it in size 42?', 'Você tem no tamanho 42?'], ['That’s too expensive for me.', 'Está caro demais pra mim.'], ['I’ll pay by card.', 'Vou pagar com cartão.']],
    opener: 'Hi, welcome to the store! Can I help you find something, or are you just looking today?',
  },
  {
    id: 'a1-family', level: 'A1', unit: 'Unit 3 · People and places', title: 'Describe family and friends',
    scenario: 'Showing a photo album to a new friend', focus: 'have got/has got, possessive ’s, descriptive adjectives',
    objectives: ['Falar da família', 'Descrever aparência e personalidade', 'Usar possessivos'],
    phrases: [['This is my sister, she’s got curly hair.', 'Esta é minha irmã, ela tem cabelo cacheado.'], ['My brother is really funny.', 'Meu irmão é muito engraçado.'], ['We’re a small family.', 'Somos uma família pequena.'], ['Whose photo is this?', 'De quem é essa foto?']],
    opener: 'Nice photo album! Who’s in this picture? Tell me about your family.',
  },
  {
    id: 'a1-home', level: 'A1', unit: 'Unit 3 · People and places', title: 'Talk about your home',
    scenario: 'A friend is visiting your apartment for the first time', focus: 'there is/there are, prepositions of place, furniture',
    objectives: ['Descrever a casa e os cômodos', 'Usar there is/there are', 'Dizer onde ficam as coisas'],
    phrases: [['There’s a small balcony next to the kitchen.', 'Tem uma varanda pequena ao lado da cozinha.'], ['My bedroom is upstairs.', 'Meu quarto fica no andar de cima.'], ['Make yourself at home!', 'Sinta-se em casa!'], ['The sofa goes in front of the window.', 'O sofá fica na frente da janela.']],
    opener: 'Thanks for having me over! Wow, your place is nice. Can you give me a quick tour?',
  },
  {
    id: 'a1-directions', level: 'A1', unit: 'Unit 3 · People and places', title: 'Ask for and give directions',
    scenario: 'A tourist asks you for directions in your city', focus: 'imperatives, prepositions of movement, polite requests',
    objectives: ['Pedir informação na rua', 'Dar direções simples', 'Confirmar entendimento'],
    phrases: [['Excuse me, how do I get to the metro station?', 'Com licença, como chego ao metrô?'], ['Go straight and turn left at the bank.', 'Siga reto e vire à esquerda no banco.'], ['It’s about five minutes on foot.', 'Fica cerca de cinco minutos a pé.'], ['Is it far from here?', 'É longe daqui?']],
    opener: 'Excuse me! Sorry to bother you — I’m a bit lost. How do I get to the central metro station?',
  },

  /* ---------------------------------- A2 ---------------------------------- */
  {
    id: 'a2-cafe', level: 'A2', unit: 'Unit 4 · Social life', title: 'Order food and drinks at a café',
    scenario: 'Ordering breakfast at a busy café', focus: 'would like, countable/uncountable, requests',
    objectives: ['Fazer pedidos com would like', 'Perguntar sobre o menu', 'Resolver um pedido errado'],
    phrases: [['I’d like a flat white and a croissant, please.', 'Eu queria um flat white e um croissant, por favor.'], ['Does it come with milk alternatives?', 'Vem com opções de leite vegetal?'], ['Sorry, I ordered tea, not coffee.', 'Desculpe, pedi chá, não café.'], ['Could we get the bill, please?', 'Poderia trazer a conta, por favor?']],
    opener: 'Good morning! Welcome to our café. What can I get for you today?',
  },
  {
    id: 'a2-plans', level: 'A2', unit: 'Unit 4 · Social life', title: 'Make plans and invite people',
    scenario: 'Inviting a friend to a concert next weekend', focus: 'present continuous for future, suggestions, do you fancy…',
    objectives: ['Convidar e aceitar/recusar', 'Sugerir horários e lugares', 'Confirmar planos por mensagem'],
    phrases: [['Do you fancy going to a concert on Saturday?', 'Tá a fim de ir a um show no sábado?'], ['I’m seeing my parents in the morning.', 'Vou ver meus pais de manhã.'], ['Let’s meet at the entrance at 8.', 'Vamos nos encontrar na entrada às 8.'], ['Sounds good to me!', 'Pra mim está ótimo!']],
    opener: 'Hey, it’s been a while! Do you have any plans for next weekend?',
  },
  {
    id: 'a2-weekend', level: 'A2', unit: 'Unit 4 · Social life', title: 'Small talk about your weekend',
    scenario: 'Monday morning chat at the office kitchen', focus: 'past simple regular/irregular, time expressions',
    objectives: ['Contar o que fez no fim de semana', 'Fazer perguntas no passado', 'Reagir com naturalidade'],
    phrases: [['I went hiking with my cousins.', 'Fui fazer trilha com meus primos.'], ['Did you do anything fun?', 'Você fez algo legal?'], ['We stayed home and watched a series.', 'Ficamos em casa vendo uma série.'], ['That sounds like a great Sunday.', 'Parece ter sido um ótimo domingo.']],
    opener: 'Morning! How was your weekend? Did you do anything interesting?',
  },
  {
    id: 'a2-job', level: 'A2', unit: 'Unit 5 · Work and study', title: 'Talk about your job and studies',
    scenario: 'Networking coffee break at an event', focus: 'work vocabulary, present simple vs continuous, "I work as…"',
    objectives: ['Explicar o que você faz', 'Falar de estudos e projetos atuais', 'Perguntar sobre a carreira do outro'],
    phrases: [['I work as a product designer.', 'Trabalho como designer de produto.'], ['I’m studying for a certification.', 'Estou estudando pra uma certificação.'], ['What do you do exactly?', 'O que exatamente você faz?'], ['I’ve been in this area for three years.', 'Estou nessa área há três anos.']],
    opener: 'Hi, I don’t think we’ve met — I’m Alex. So, what do you do?',
  },
  {
    id: 'a2-interview', level: 'A2', unit: 'Unit 5 · Work and study', title: 'A simple job interview',
    scenario: 'First-round interview for an internship', focus: 'tell me about yourself, why + because, polite register',
    objectives: ['Responder "tell me about yourself"', 'Falar de forças e fraquezas', 'Fazer perguntas ao recrutador'],
    phrases: [['I’m a fast learner and I enjoy teamwork.', 'Aprendo rápido e gosto de trabalhar em equipe.'], ['Could you tell me more about the role?', 'Você poderia me contar mais sobre a vaga?'], ['My biggest challenge was public speaking.', 'Meu maior desafio foi falar em público.'], ['I’m available to start next month.', 'Tenho disponibilidade pra começar mês que vem.']],
    opener: 'Thanks for coming in today. Let’s start easy: tell me a little about yourself.',
  },
  {
    id: 'a2-experience', level: 'A2', unit: 'Unit 5 · Work and study', title: 'Describe past work experience',
    scenario: 'Explaining your CV to a recruiter', focus: 'past simple vs present perfect, for/since, ago',
    objectives: ['Narrar experiências passadas', 'Usar for/since/ago corretamente', 'Explicar mudanças de área'],
    phrases: [['I worked at a startup for two years.', 'Trabalhei numa startup por dois anos.'], ['I’ve worked with data since 2021.', 'Trabalho com dados desde 2021.'], ['I moved to marketing three years ago.', 'Mudei pro marketing há três anos.'], ['That experience taught me a lot.', 'Essa experiência me ensinou muito.']],
    opener: 'I read your CV — nice background! Walk me through your last job. What did you do there?',
  },
  {
    id: 'a2-checkin', level: 'A2', unit: 'Unit 6 · Travel', title: 'Airport and hotel check-in',
    scenario: 'Checking into a hotel after a long flight', focus: 'requests with could/do you mind, travel vocabulary',
    objectives: ['Fazer check-in em hotel', 'Pedir informações e serviços', 'Resolver problemas do quarto'],
    phrases: [['I have a reservation under Silva.', 'Tenho uma reserva no nome Silva.'], ['Could I have a wake-up call at 6?', 'Poderia me acordar às 6?'], ['The air conditioning isn’t working.', 'O ar-condicionado não está funcionando.'], ['Is breakfast included?', 'O café da manhã está incluso?']],
    opener: 'Good evening, welcome to the Riverside Hotel! Do you have a reservation with us?',
  },
  {
    id: 'a2-tickets', level: 'A2', unit: 'Unit 6 · Travel', title: 'Buy tickets and ask for help',
    scenario: 'At a train station ticket office', focus: 'one-way/return, questions with how long/which, polite asking',
    objectives: ['Comprar passagens', 'Perguntar plataforma e horários', 'Entender mudanças de plano'],
    phrases: [['A return ticket to Brighton, please.', 'Uma passagem de ida e volta pra Brighton, por favor.'], ['Which platform does it leave from?', 'De qual plataforma ele sai?'], ['How long does the journey take?', 'Quanto tempo dura a viagem?'], ['I missed my connection.', 'Perdi minha conexão.']],
    opener: 'Next in line, please! Where are you travelling to today?',
  },
  {
    id: 'a2-travel-story', level: 'A2', unit: 'Unit 6 · Travel', title: 'Tell a travel story',
    scenario: 'Sharing a trip story with friends at dinner', focus: 'past simple irregular, sequencing words, reactions',
    objectives: ['Narrar uma viagem em ordem', 'Usar first/then/after that', 'Reagir a histórias'],
    phrases: [['We got lost in the old town.', 'Nos perdemos na cidade antiga.'], ['Then it started raining really hard.', 'Aí começou a chover muito forte.'], ['In the end, a local family helped us.', 'No fim, uma família local nos ajudou.'], ['You’re kidding! What happened next?', 'Tá brincando! E aí, o que aconteceu?']],
    opener: 'So, tell me about your last trip! Where did you go and what happened?',
  },

  /* ---------------------------------- B1 ---------------------------------- */
  {
    id: 'b1-opinions', level: 'B1', unit: 'Unit 7 · Opinion and narrative', title: 'Give opinions and agree or disagree',
    scenario: 'Discussion about remote work with a colleague', focus: 'I reckon/In my view, agreeing and disagreeing politely',
    objectives: ['Dar opinião com justificativa', 'Concordar e discordar com educação', 'Pedir a opinião do outro'],
    phrases: [['I reckon remote work suits some roles better.', 'Acho que o trabalho remoto combina mais com certas funções.'], ['I see your point, but…', 'Entendo seu ponto, mas…'], ['That’s a fair point.', 'É um argumento justo.'], ['Where do you stand on this?', 'Qual é a sua posição sobre isso?']],
    opener: 'Our company is debating a full return to the office. Personally, I have mixed feelings. What’s your take on it?',
  },
  {
    id: 'b1-story', level: 'B1', unit: 'Unit 7 · Opinion and narrative', title: 'Tell a story with linking words',
    scenario: 'Explaining a project that went wrong', focus: 'because/although/so, past perfect, narrative tenses',
    objectives: ['Estruturar uma narrativa', 'Usar past perfect', 'Fechar com uma lição aprendida'],
    phrases: [['We had already launched when we noticed the bug.', 'Já tínhamos lançado quando notamos o bug.'], ['Although we were late, we fixed it fast.', 'Apesar de atrasados, corrigimos rápido.'], ['Looking back, we should have tested more.', 'Olhando pra trás, deveríamos ter testado mais.'], ['The lesson was clear.', 'A lição foi clara.']],
    opener: 'You look like you have a story to tell. Tell me about a project that didn’t go as planned — what happened?',
  },
  {
    id: 'b1-complaints', level: 'B1', unit: 'Unit 7 · Opinion and narrative', title: 'Describe problems and complain politely',
    scenario: 'Calling a company about a delayed delivery', focus: 'polite complaint structures, modals, escalation',
    objectives: ['Reclamar sem soar agressivo', 'Explicar impacto e pedir solução', 'Escalar para um supervisor'],
    phrases: [['I’m calling about an order that never arrived.', 'Estou ligando sobre um pedido que nunca chegou.'], ['I’d appreciate it if you could check.', 'Eu agradeceria se você pudesse verificar.'], ['This has caused a real problem for us.', 'Isso causou um problema real pra nós.'], ['Could I speak to a supervisor?', 'Poderia falar com um supervisor?']],
    opener: 'Good afternoon, customer support — this is Alex. How can I help you today?',
  },
  {
    id: 'b1-meeting', level: 'B1', unit: 'Unit 8 · Meetings and ideas', title: 'Run a short meeting',
    scenario: 'Leading a weekly team check-in', focus: 'meeting language, sequencing an agenda, action items',
    objectives: ['Abrir e conduzir uma reunião', 'Distribuir a palavra e resumir', 'Fechar com próximos passos'],
    phrases: [['Let’s kick off with the numbers.', 'Vamos começar pelos números.'], ['Can we park that for later?', 'Podemos deixar isso pra depois?'], ['To sum up, we have two priorities.', 'Resumindo, temos duas prioridades.'], ['Who’s taking the action on this?', 'Quem assume essa ação?']],
    opener: 'Alright, we’re on a tight schedule — let’s start the weekly check-in. You’re leading today. What’s first on the agenda?',
  },
  {
    id: 'b1-process', level: 'B1', unit: 'Unit 8 · Meetings and ideas', title: 'Explain a process step by step',
    scenario: 'Onboarding a new team member', focus: 'passive voice, sequencing, cause and effect',
    objectives: ['Explicar processos com clareza', 'Usar voz passiva', 'Testar a compreensão do ouvinte'],
    phrases: [['First, the request is logged in the system.', 'Primeiro, a solicitação é registrada no sistema.'], ['After that, it’s reviewed by two people.', 'Depois disso, é revisada por duas pessoas.'], ['Does that make sense so far?', 'Está fazendo sentido até aqui?'], ['Where would you go to check the status?', 'Onde você iria pra checar o status?']],
    opener: 'I’m new here and still learning the workflow — could you walk me through how a request gets approved?',
  },
  {
    id: 'b1-negotiate', level: 'B1', unit: 'Unit 8 · Meetings and ideas', title: 'Negotiate deadlines and priorities',
    scenario: 'A stakeholder wants the delivery earlier', focus: 'conditionals, trade-offs, firm but collaborative tone',
    objectives: ['Negociar prazos', 'Oferecer alternativas', 'Dizer não com clareza'],
    phrases: [['If we bring the date forward, we’ll drop testing.', 'Se anteciparmos, vamos cortar testes.'], ['What if we deliver in two phases?', 'E se entregarmos em duas fases?'], ['I can commit to Friday, but not Wednesday.', 'Consigo garantir sexta, mas não quarta.'], ['That works if we keep the scope frozen.', 'Isso funciona se mantivermos o escopo congelado.']],
    opener: 'Look, leadership wants this live two weeks earlier. I know it’s tight. What can you realistically commit to?',
  },
  {
    id: 'b1-media', level: 'B1', unit: 'Unit 9 · Culture and media', title: 'Talk about films, series and books',
    scenario: 'Recommending a series to a friend', focus: 'present perfect, describing plots, adjectives of judgement',
    objectives: ['Descrever enredo sem spoilers', 'Recomendar e avaliar', 'Comparar gêneros'],
    phrases: [['Have you seen the new season yet?', 'Você já viu a temporada nova?'], ['It’s gripping but a bit slow at first.', 'É envolvente, mas meio lento no começo.'], ['I couldn’t put it down.', 'Não consegui largar.'], ['It’s nowhere near as good as the book.', 'Não chega nem perto do livro.']],
    opener: 'I need a recommendation — I’ve just finished a series and I’m lost. What have you been watching lately?',
  },
  {
    id: 'b1-news', level: 'B1', unit: 'Unit 9 · Culture and media', title: 'Discuss a news topic',
    scenario: 'Debating a tech headline over lunch', focus: 'present perfect for recent news, cause/consequence, hedging',
    objectives: ['Comentar notícias recentes', 'Expressar dúvida e ceticismo', 'Estruturar argumento'],
    phrases: [['Have you read about the new AI rules?', 'Você leu sobre as novas regras de IA?'], ['It seems to have happened overnight.', 'Parece que aconteceu da noite pro dia.'], ['I’m not convinced that will work.', 'Não estou convencido de que isso vai funcionar.'], ['It could go either way.', 'Pode dar certo ou não.']],
    opener: 'Did you see the news about new AI regulation in Europe? I keep going back and forth on it. What do you think?',
  },
  {
    id: 'b1-hypothetical', level: 'B1', unit: 'Unit 9 · Culture and media', title: 'Talk about hypothetical situations',
    scenario: 'Playing a "what would you do" game', focus: 'second conditional, would/were, speculation',
    objectives: ['Usar o segundo condicional', 'Especular e imaginar', 'Justificar escolhas'],
    phrases: [['If I had more time, I’d learn guitar.', 'Se eu tivesse mais tempo, aprenderia violão.'], ['What would you do in my position?', 'O que você faria no meu lugar?'], ['If I were you, I’d ask for a raise.', 'Se eu fosse você, pediria aumento.'], ['I’d probably panic, honestly.', 'Sinceramente, eu provavelmente entraria em pânico.']],
    opener: 'Let’s play a game. Scenario: you win a year off work with full pay. What would you do?',
  },

  /* ---------------------------------- B2 ---------------------------------- */
  {
    id: 'b2-debate', level: 'B2', unit: 'Unit 10 · Fluency and nuance', title: 'Debate a controversial topic',
    scenario: 'Structured debate about four-day work weeks', focus: 'concession, rebuttal, rhetorical devices',
    objectives: ['Sustentar uma posição por vários turnos', 'Rebater com evidência', 'Conceder e redirecionar'],
    phrases: [['While I accept the productivity data, it’s cherry-picked.', 'Aceito os dados de produtividade, mas são escolhidos a dedo.'], ['That argument collapses if demand is seasonal.', 'Esse argumento cai se a demanda for sazonal.'], ['Let’s separate the principle from the execution.', 'Vamos separar o princípio da execução.'], ['On balance, I’d still argue…', 'No geral, eu ainda defenderia…']],
    opener: 'Tonight’s motion: a four-day week should be mandatory. I’ll take the opposition side. Give me your strongest opening argument.',
  },
  {
    id: 'b2-hedging', level: 'B2', unit: 'Unit 10 · Fluency and nuance', title: 'Soften and hedge like a native',
    scenario: 'Giving feedback without sounding harsh', focus: 'hedging, vague language, downtoners, politeness',
    objectives: ['Suavizar afirmações', 'Usar vague language', 'Dar feedback difícil'],
    phrases: [['There’s a slight issue with the timeline.', 'Tem uma pequena questão com o cronograma.'], ['It’s not exactly what we agreed, to be fair.', 'Não é exatamente o que combinamos, convenhamos.'], ['You might want to double-check the figures.', 'Talvez valha a pena revisar os números.'], ['I’d be a bit careful with that phrasing.', 'Eu tomaria cuidado com esse fraseado.']],
    opener: 'So — how do you usually handle telling a colleague their work isn’t good enough? Walk me through it in English.',
  },
  {
    id: 'b2-data', level: 'B2', unit: 'Unit 10 · Fluency and nuance', title: 'Explain data and trends',
    scenario: 'Presenting quarterly results to leadership', focus: 'describing graphs, approximating, causal language',
    objectives: ['Descrever tendências', 'Comparar períodos', 'Explicar causas com cautela'],
    phrases: [['Revenue grew by roughly 12% year on year.', 'A receita cresceu cerca de 12% ano a ano.'], ['There was a sharp dip in Q3.', 'Houve uma queda acentuada no 3º trimestre.'], ['This correlates with the price change.', 'Isso se correlaciona com a mudança de preço.'], ['We’re cautiously optimistic about Q4.', 'Estamos cautelosamente otimistas com o 4º trimestre.']],
    opener: 'You’re presenting the quarterly numbers in five minutes. Start: how did the quarter go?',
  },
  {
    id: 'b2-client', level: 'B2', unit: 'Unit 11 · Professional English', title: 'Lead a client call',
    scenario: 'Kickoff call with an international client', focus: 'agenda setting, managing turn-taking, summarising',
    objectives: ['Conduzir uma call com cliente', 'Gerenciar expectativas', 'Resumir decisões e responsáveis'],
    phrases: [['Thanks for making the time today.', 'Obrigado por reservar um tempo hoje.'], ['Before we dive in, any additions to the agenda?', 'Antes de começarmos, querem acrescentar algo à pauta?'], ['Let me play that back to make sure I got it.', 'Vou repetir pra confirmar que entendi.'], ['I’ll send the summary within the hour.', 'Envio o resumo dentro de uma hora.']],
    opener: 'Hi, thanks for joining. I’ve got 30 minutes and a short agenda. Ready to start with introductions?',
  },
  {
    id: 'b2-present', level: 'B2', unit: 'Unit 11 · Professional English', title: 'Present a project with impact',
    scenario: 'Pitching an internal project to stakeholders', focus: 'emphasis, cleft sentences, signposting',
    objectives: ['Estruturar um pitch curto', 'Enfatizar pontos-chave', 'Responder perguntas difíceis'],
    phrases: [['What really sets this apart is the speed.', 'O que realmente diferencia isso é a velocidade.'], ['It’s the cost savings that matter most.', 'São as economias de custo que mais importam.'], ['Let me put that in context.', 'Deixa eu colocar isso em contexto.'], ['The key takeaway is simple.', 'A conclusão principal é simples.']],
    opener: 'The floor is yours — three minutes to convince me to fund your project. Go ahead.',
  },
  {
    id: 'b2-conflict', level: 'B2', unit: 'Unit 11 · Professional English', title: 'Handle conflict and give feedback',
    scenario: 'Mediating a tense disagreement between teammates', focus: 'de-escalation, reframing, assertive I-statements',
    objectives: ['Mediar conflitos', 'Reformular posições', 'Fechar com acordo mútuo'],
    phrases: [['Let’s step back and look at the goal.', 'Vamos voltar e olhar o objetivo.'], ['I hear the frustration, and it’s valid.', 'Entendo a frustração, e ela é legítima.'], ['Can we agree on one thing to try this week?', 'Podemos concordar em uma coisa pra testar esta semana?'], ['I’d rather we attack the problem, not each other.', 'Prefiro que ataquemos o problema, não uns aos outros.']],
    opener: 'Two people on your team just had a shouting match in the chat. You’re mediating. How do you open the conversation?',
  },
  {
    id: 'b2-idioms', level: 'B2', unit: 'Unit 12 · Naturalness', title: 'Idioms and phrasal verbs in context',
    scenario: 'Casual after-work drinks with native speakers', focus: 'idioms, phrasal verbs, register awareness',
    objectives: ['Usar phrasal verbs naturalmente', 'Entender ironia e gírias comuns', 'Ajustar registro'],
    phrases: [['We pulled it off at the last minute.', 'Conseguimos na última hora.'], ['I’m swamped this week, to be honest.', 'Estou atolado esta semana, sinceramente.'], ['Let’s touch base on Monday.', 'Vamos nos falar na segunda.'], ['That’s a bit of a stretch, isn’t it?', 'Isso é meio forçado, não é?']],
    opener: 'Finally off the clock! How was your week — busy or manageable?',
  },
  {
    id: 'b2-humour', level: 'B2', unit: 'Unit 12 · Naturalness', title: 'Tell jokes and handle cultural references',
    scenario: 'Banter with international friends at a barbecue', focus: 'humour timing, teasing, cultural references',
    objectives: ['Contar uma piada curta em inglês', 'Brincar sem ofender', 'Responder a piadas'],
    phrases: [['You’ve got to be kidding me!', 'Você só pode estar brincando!'], ['Classic Monday, right?', 'Típico de segunda, né?'], ['I’m only teasing — relax!', 'Estou só zoando — relaxa!'], ['That joke landed perfectly.', 'Essa piada caiu perfeitamente.']],
    opener: 'Okay, barbecue rule: everyone brings one joke or story. Your turn — make me laugh.',
  },
  {
    id: 'b2-free', level: 'B2', unit: 'Unit 12 · Naturalness', title: 'Free talk: sound natural and confident',
    scenario: 'Unscripted conversation on any topic', focus: 'fillers, intonation, self-correction, fluency',
    objectives: ['Falar por vários minutos sem travar', 'Usar fillers naturais', 'Se autocorrigir com fluidez'],
    phrases: [['That’s a good question, let me think.', 'Boa pergunta, deixa eu pensar.'], ['I mean, it depends, right?', 'Quer dizer, depende, né?'], ['Anyway, where was I…', 'Enfim, onde eu estava…'], ['Sorry, I meant to say…', 'Desculpa, eu quis dizer…']],
    opener: 'Free talk today — no script. Tell me about something you’ve changed your mind about recently.',
  },
]

export const FREE_TOPICS = [
  'Your perfect weekend in your city',
  'A decision that changed your career',
  'Technology you would ban tomorrow',
  'Food from your childhood',
  'A book everyone should read',
  'What you would tell your 18-year-old self',
  'Living abroad: dream or nightmare?',
  'The best advice you ever received',
  'Money and happiness',
  'Your most embarrassing English mistake',
]

export const byId = (id) => LESSONS.find((l) => l.id === id) || null

export function planForLevel(level) {
  const order = ['A1', 'A2', 'B1', 'B2']
  const upTo = order.indexOf(level) < 0 ? 0 : order.indexOf(level)
  // Aluno vê tudo até o seu nível (revisão) + primeiro bloco do nível seguinte (desafio).
  const allowed = order.slice(0, Math.min(upTo + 2, order.length))
  return LESSONS.filter((l) => allowed.includes(l.level))
}

export function unitsFor(lessons) {
  const map = new Map()
  for (const l of lessons) {
    if (!map.has(l.unit)) map.set(l.unit, { unit: l.unit, level: l.level, lessons: [] })
    map.get(l.unit).lessons.push(l)
  }
  return [...map.values()]
}
