/**
 * Camada de IA.
 *
 * Provedores suportados: openai | gemini | anthropic | mock (demo offline).
 * A chave pode vir do .env (AI_API_KEY) ou do próprio usuário (salva criptografada).
 *
 * O tutor sempre responde num JSON com o formato:
 * { reply, correction: {has_error, corrected, explanation}, vocab: [{term, meaning}], hint }
 */

const TIMEOUT_MS = 25_000

/* --------------------------------- prompt --------------------------------- */

export function buildSystemPrompt({ lesson, level, goal, userName, recurring = [] }) {
  const lessonBlock = lesson
    ? `LESSON: ${lesson.title}
SCENARIO: ${lesson.scenario}
TARGET LANGUAGE FOCUS: ${lesson.focus}
LESSON OBJECTIVES (in Portuguese, for your planning only): ${lesson.objectives.join('; ')}
TARGET CHUNKS THE STUDENT SHOULD PRACTISE: ${lesson.phrases.map((p) => `"${p[0]}"`).join(', ')}
FIRST LINE OF THE SCENE (already spoken): "${lesson.opener}"`
    : `FREE CONVERSATION: no fixed lesson. Explore the student's topic naturally.`

  return `You are Alex, a warm, patient and sharp English tutor in a voice-based conversation app for Brazilian learners of Portuguese-speaking background.

STUDENT: ${userName || 'the student'} — CEFR level ${level}. Goal: ${goal || 'conversation'}.
${recurring.length ? `RECURRING MISTAKES TO WATCH: ${recurring.join(', ')}` : ''}

${lessonBlock}

HOW YOU TEACH:
- Stay in character inside the scenario. Role-play naturally; don't announce you are an AI or a language model.
- Speak English only (the student's level: ${level}), simple and clear sentences. Never more than 3-4 sentences per turn.
- Always end your turn with ONE question that keeps the conversation (and the student) moving.
- If the student makes a mistake, DO NOT interrupt the flow with a lecture. Put the fix in the "correction" field and continue the conversation naturally, reusing the corrected form once in your reply when it fits.
- Adapt: if the student struggles (very short answers, "I don't know", Portuguese), lower the difficulty, give a model answer and ask an easier question. If the student is fluent, push with follow-ups, collocations and nuance.
- Nudge the student toward the target chunks and objectives, one step at a time.
- Be encouraging and specific. Never invent facts about the student.

OUTPUT — reply with ONLY valid JSON, no markdown, in this exact shape:
{
  "reply": "your spoken turn in English",
  "correction": { "has_error": false, "corrected": "", "explanation": "" },
  "vocab": [{ "term": "english term worth saving", "meaning": "explicação curta em português" }],
  "hint": "optional nudge in Portuguese for the student's next answer (max 12 words)"
}

Rules for the fields:
- "correction": only when the student's LAST message has a real grammar, vocabulary or word-order problem. Set has_error=true, put the student's sentence rewritten correctly in "corrected" and a short explanation in Portuguese (max 20 words) in "explanation". Otherwise has_error=false and empty strings.
- "vocab": 0 to 2 useful English terms from YOUR reply or the lesson that this student probably doesn't know yet.
- "hint": only when useful; helps the student answer your question.`
}

/* --------------------------------- helpers -------------------------------- */

function extractJson(raw) {
  if (!raw) return null
  let text = String(raw).trim()
  text = text.replace(/^```(?:json)?/i, '').replace(/```$/, '').trim()
  const start = text.indexOf('{')
  const end = text.lastIndexOf('}')
  if (start === -1 || end === -1) return null
  const slice = text.slice(start, end + 1).replace(/,\s*([}\]])/g, '$1')
  try {
    return JSON.parse(slice)
  } catch {
    return null
  }
}

function normalize(parsed, fallbackText = '') {
  const out = { reply: '', correction: { has_error: false, corrected: '', explanation: '' }, vocab: [], hint: '' }
  if (!parsed) {
    out.reply = fallbackText || "Sorry, I didn't catch that. Could you say it again?"
    return out
  }
  out.reply = typeof parsed.reply === 'string' && parsed.reply.trim() ? parsed.reply.trim() : fallbackText || 'Okay! Go on.'
  const c = parsed.correction
  if (c && typeof c === 'object' && (c.has_error || (c.corrected && c.corrected.trim()))) {
    out.correction = {
      has_error: Boolean(c.has_error ?? true),
      corrected: String(c.corrected || '').trim(),
      explanation: String(c.explanation || '').trim(),
    }
  }
  if (Array.isArray(parsed.vocab)) {
    out.vocab = parsed.vocab
      .filter((v) => v && v.term)
      .slice(0, 3)
      .map((v) => ({ term: String(v.term).trim(), meaning: String(v.meaning || '').trim(), example: String(v.example || '').trim() }))
  }
  out.hint = typeof parsed.hint === 'string' ? parsed.hint.trim() : ''
  return out
}

async function post(url, { headers = {}, body, signal } = {}) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...headers },
    body: JSON.stringify(body),
    signal,
  })
  const text = await res.text()
  if (!res.ok) {
    let detail = text.slice(0, 300)
    try {
      const j = JSON.parse(text)
      detail = j?.error?.message || j?.message || detail
    } catch {}
    throw Object.assign(new Error(`${res.status} ${detail}`), { status: res.status })
  }
  return text ? JSON.parse(text) : {}
}

/* -------------------------------- providers ------------------------------- */

async function callOpenAI({ apiKey, system, messages, model = 'gpt-4o-mini', signal }) {
  const data = await post('https://api.openai.com/v1/chat/completions', {
    headers: { authorization: `Bearer ${apiKey}` },
    body: {
      model,
      temperature: 0.7,
      response_format: { type: 'json_object' },
      messages: [{ role: 'system', content: system }, ...messages],
    },
    signal,
  })
  return data?.choices?.[0]?.message?.content || ''
}

async function callGemini({ apiKey, system, messages, model = 'gemini-2.5-flash', signal }) {
  const data = await post(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    {
      headers: { 'x-goog-api-key': apiKey },
      body: {
        systemInstruction: { parts: [{ text: system }] },
        contents: messages.map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })),
        generationConfig: { temperature: 0.7, responseMimeType: 'application/json' },
      },
      signal,
    }
  )
  return data?.candidates?.[0]?.content?.parts?.map((p) => p.text).join('') || ''
}

async function callAnthropic({ apiKey, system, messages, model = 'claude-sonnet-4-5', signal }) {
  const data = await post('https://api.anthropic.com/v1/messages', {
    headers: { 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: {
      model,
      max_tokens: 800,
      temperature: 0.7,
      system,
      messages: [
        ...messages,
        { role: 'assistant', content: '{' }, // prefill força o JSON
      ],
    },
    signal,
  })
  const raw = data?.content?.map((c) => c.text).join('') || ''
  return raw ? `{${raw}` : ''
}

async function callOpenRouter({ apiKey, system, messages, model = 'openai/gpt-4o-mini', signal }) {
  const data = await post('https://openrouter.ai/api/v1/chat/completions', {
    headers: { authorization: `Bearer ${apiKey}` },
    body: { model, temperature: 0.7, messages: [{ role: 'system', content: system }, ...messages] },
    signal,
  })
  return data?.choices?.[0]?.message?.content || ''
}

const PROVIDERS = {
  openai: callOpenAI,
  gemini: callGemini,
  anthropic: callAnthropic,
  openrouter: callOpenRouter,
}

export const SUPPORTED_PROVIDERS = [...Object.keys(PROVIDERS), 'mock']

/** Gera o turno do tutor. Nunca lança: em falha, cai no modo demo com aviso. */
export async function tutorTurn({ provider, apiKey, system, messages, lesson }) {
  const messagesForApi = messages.slice(-12).map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content }))

  if (!provider || provider === 'mock' || !apiKey) {
    return { ...mockTurn({ messages, lesson }), provider: 'mock', degraded: !apiKey && provider && provider !== 'mock' }
  }

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS)
  try {
    const raw = await PROVIDERS[provider]({ apiKey, system, messages: messagesForApi, signal: controller.signal })
    const parsed = extractJson(raw)
    const result = normalize(parsed, parsed ? '' : raw)
    if (!result.reply) throw new Error('empty reply')
    return { ...result, provider, degraded: false }
  } catch (err) {
    const fallback = mockTurn({ messages, lesson })
    return {
      ...fallback,
      provider: 'mock',
      degraded: true,
      error: String(err.message || err).slice(0, 200),
    }
  } finally {
    clearTimeout(timer)
  }
}

/* ------------------------------ modo demonstração -------------------------- */

const RULES = [
  [/\bi have (\d+|twenty|thirty|forty|\w+) years?\b/i, (m) => `I am ${m[1]} years old`, 'Em inglês não se usa "have" para idade — use "I am ... years old".'],
  [/\bi am agree\b/i, () => 'I agree', '"Agree" já é verbo: "I agree", sem "am".'],
  [/\bmore better\b/i, () => 'better', '"Better" já é superlativo/comparativo: não use "more".'],
  [/\bexplain me\b/i, () => 'explain to me', 'Usa-se "explain to me" / "explain something to me".'],
  [/\bmake a question\b/i, () => 'ask a question', 'Fazemos "ask a question", não "make a question".'],
  [/\bi'?m boring\b/i, () => "I'm bored", '"Boring" = chato; "bored" = entediado.'],
  [/\b(he|she|it) don't\b/i, (m) => `${m[1]} doesn't`, 'Terceira pessoa do singular usa "doesn\'t".'],
  [/\bdidn'?t went\b/i, () => "didn't go", 'Depois de "didn\'t" o verbo fica na base: "didn\'t go".'],
  [/\bpeople is\b/i, () => 'people are', '"People" é plural: "people are".'],
  [/\bdepend of\b/i, () => 'depend on', 'A preposição correta é "depend on".'],
  [/\bmarried with\b/i, () => 'married to', 'Usa-se "married to someone".'],
  [/\bgood in (english|math|sports|it)\b/i, (m) => `good at ${m[1]}`, 'Com habilidades usamos "good at".'],
  [/\bfor to\b/i, () => 'to', '"For to" não existe: use só "to" ou "in order to".'],
  [/\bi go .* yesterday\b/i, (m) => m[0].replace(/\bgo\b/i, 'went'), 'Ontem pede passado: "went", não "go".'],
  [/\bwork like\b/i, () => 'work as', 'Profissão usa "work as a designer", não "work like".'],
  [/\bin the (weekend|morning|afternoon|evening)\b/i, (m) => `on the ${m[1]}`, 'Usa-se "on the weekend" (e "in the morning").'],
  [/\bi born in\b/i, () => 'I was born in', '"Nascer" pede passiva: "I was born in...".'],
  [/\bsince (\d+|two|three|four|five) years\b/i, (m) => `for ${m[1]} years`, 'Duração usa "for"; "since" pede um ponto no tempo (since 2021).'],
  [/\bmore easy\b/i, () => 'easier', 'Adjetivos curtos formam o comparativo com -er.'],
  [/\bpeoples\b/i, () => 'people', '"People" já é plural — sem "s".'],
  [/\bif i would\b/i, () => 'if I had / if I were', 'No condicional, "if" não leva "would".'],
  [/\bthe most big\b/i, () => 'the biggest', 'Adjetivos curtos formam superlativo com -est.'],
]

/** Marcadores de passado + formas verbais mais comuns que precisam virar passado. */
const PAST_MARKERS = /\b(yesterday|last night|last week|last month|last year|\d+ (days?|weeks?|months?|years?) ago|in 20\d\d)\b/i
const PAST_FORMS = [
  [/\bwe have\b/i, 'we had'],
  [/\bi have\b/i, 'I had'],
  [/\bthey have\b/i, 'they had'],
  [/\bit is\b/i, 'it was'],
  [/\b(they|we|you) are\b/i, (m) => `${m[1]} were`],
  [/\b(he|she|it) is\b/i, (m) => `${m[1]} was`],
  [/\b(go|goes)\b/i, 'went'],
  [/\beat\b/i, 'ate'],
  [/\bsee\b/i, 'saw'],
  [/\bmake\b/i, 'made'],
  [/\btake\b/i, 'took'],
  [/\bget\b/i, 'got'],
  [/\bcome\b/i, 'came'],
  [/\bdo\b/i, 'did'],
  [/\bdrink\b/i, 'drank'],
  [/\bsleep\b/i, 'slept'],
  [/\bbuy\b/i, 'bought'],
]

function fixPastTense(sentence) {
  let out = sentence
  const applied = []
  for (const [re, rep] of PAST_FORMS) {
    if (re.test(out)) {
      const before = out
      out = out.replace(re, rep)
      if (before !== out) applied.push(re.source)
    }
  }
  return applied.length && out !== sentence ? out : null
}

const GENERIC_VOCAB = [
  ['That’s a good question, let me think.', 'Boa pergunta, deixa eu pensar.'],
  ['It depends on the situation.', 'Depende da situação.'],
  ['I’ve been meaning to try that.', 'Tenho querido experimentar isso.'],
  ['To be honest, I’m not sure yet.', 'Sinceramente, ainda não tenho certeza.'],
  ['That’s a fair point.', 'É um argumento justo.'],
  ['Let me put it another way.', 'Deixa eu dizer de outro jeito.'],
]

const FOLLOW_UPS = {
  A1: [
    'Nice! And what about your best friend — what’s his or her name?',
    'Good. Can you tell me one more thing? Where do you usually go on weekends?',
    'Great answer! Now try a full sentence: what time do you usually wake up?',
    'Perfect. And your family — do you live with them?',
  ],
  A2: [
    'Interesting! What did you do after that?',
    'Nice. And how often do you do that?',
    'Good — can you say that again with a bit more detail?',
    'That’s clear. What would you change about it next time?',
  ],
  B1: [
    'That makes sense. What was the hardest part of it?',
    'Good point. Can you give me an example to support that?',
    'Fair. How would your answer change if money weren’t a problem?',
    'Interesting — how does that compare with your previous experience?',
  ],
  B2: [
    'Strong point. What’s the strongest counter-argument to that?',
    'I follow you. Could you qualify that — what are the limits of your claim?',
    'Interesting take. How would you defend that under pressure from a sceptic?',
    'Good. What evidence would change your mind?',
  ],
}

function mockTurn({ messages = [], lesson }) {
  const lastUser = [...messages].reverse().find((m) => m.role === 'user')?.content || ''
  const level = lesson?.level || 'A2'
  const correction = { has_error: false, corrected: '', explanation: '' }
  let out = lastUser
  const reasons = []

  for (const [re, fix, explanation] of RULES) {
    if (reasons.length >= 2) break
    const m = out.match(re)
    if (m) {
      const next = out.replace(re, fix(m))
      if (next !== out) {
        out = next
        reasons.push(explanation)
      }
    }
  }
  if (!reasons.length && PAST_MARKERS.test(lastUser)) {
    const fixed = fixPastTense(lastUser)
    if (fixed) {
      out = fixed
      reasons.push('Você está falando do passado — os verbos precisam ir para o passado.')
    }
  }
  if (!reasons.length && lastUser.length > 3 && /^[a-z]/.test(lastUser)) {
    out = lastUser
    reasons.push('Em inglês, comece a frase com letra maiúscula.')
  }
  if (reasons.length) {
    correction.has_error = true
    correction.corrected = out.replace(/^[a-z]/, (c) => c.toUpperCase())
    correction.explanation = reasons.join(' ')
  }

  const bank = FOLLOW_UPS[level] || FOLLOW_UPS.A2
  const seed = (lastUser.length + (lesson?.id?.length || 0)) % bank.length
  const words = lastUser.split(/\s+/).filter(Boolean).length
  const ack = words <= 2 ? 'Short but clear!' : words <= 8 ? 'Good, that works.' : 'Nice, you’re building longer sentences.'
  const praise = correction.has_error ? `Small fix first: “${correction.corrected}”.` : ack

  return {
    reply: `${praise} ${bank[seed]}`,
    correction,
    vocab: (() => {
      const pool = lesson?.phrases?.length ? lesson.phrases : GENERIC_VOCAB
      if (words > 10) return []
      const pick = pool[seed % pool.length]
      return [{ term: pick[0], meaning: pick[1] }]
    })(),
    hint: lesson?.objectives?.length ? `Tente usar: ${lesson.objectives[seed % lesson.objectives.length]}` : '',
    demo: true,
  }
}

/* ----------------------------------- TTS ---------------------------------- */

/** Sintetiza voz no servidor quando o provedor tiver TTS. Retorna {buffer, mime} ou null. */
export async function synthesize(text, { provider, apiKey, voice = 'nova' }) {
  if (!apiKey || !text) return null
  try {
    if (provider === 'openai') {
      const res = await fetch('https://api.openai.com/v1/audio/speech', {
        method: 'POST',
        headers: { authorization: `Bearer ${apiKey}`, 'content-type': 'application/json' },
        body: JSON.stringify({ model: 'gpt-4o-mini-tts', voice, input: text.slice(0, 1200), response_format: 'mp3' }),
      })
      if (!res.ok) return null
      return { buffer: Buffer.from(await res.arrayBuffer()), mime: 'audio/mpeg' }
    }
    if (provider === 'elevenlabs') {
      const voiceId = voice || 'EXAVITQu4vr4xnSDxMaL'
      const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: 'POST',
        headers: { 'xi-api-key': apiKey, 'content-type': 'application/json' },
        body: JSON.stringify({ text: text.slice(0, 1200), model_id: 'eleven_turbo_v2_5' }),
      })
      if (!res.ok) return null
      return { buffer: Buffer.from(await res.arrayBuffer()), mime: 'audio/mpeg' }
    }
  } catch {
    /* cai no fallback do navegador */
  }
  return null
}
