import express from 'express'
import path from 'node:path'
import fs from 'node:fs'
import crypto from 'node:crypto'
import {
  db, today, dayOffset, encrypt, decrypt, hashPassword, verifyPassword, touchStreak, addXp,
} from './db.js'
import { LESSONS, LEVELS, GOALS, FREE_TOPICS, byId, planForLevel, unitsFor } from './curriculum.js'
import { buildSystemPrompt, tutorTurn, synthesize, SUPPORTED_PROVIDERS } from './ai.js'

/* --------------------------------- .env ---------------------------------- */
const envFile = path.join(process.cwd(), '.env')
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i)
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '')
  }
}

const app = express()
app.disable('x-powered-by')
app.use(express.json({ limit: '1mb' }))

const PORT = Number(process.env.PORT || 4173)
const ENV_PROVIDER = process.env.AI_PROVIDER || null
const ENV_KEY = process.env.AI_API_KEY || null

const COOKIE = 'fluenta_session'
const publicUser = (u) => ({
  id: u.id, name: u.name, email: u.email, cefr_level: u.cefr_level, goal: u.goal,
  daily_goal_min: u.daily_goal_min, tts_voice: u.tts_voice, xp: u.xp, streak: u.streak,
  best_streak: u.best_streak, ai_provider: u.ai_provider || ENV_PROVIDER || 'mock',
  has_key: Boolean(u.ai_key_enc || ENV_KEY), key_from_env: Boolean(ENV_KEY && !u.ai_key_enc),
})

function readCookies(req) {
  const raw = req.headers.cookie || ''
  return Object.fromEntries(raw.split(';').map((c) => c.trim().split('=').map(decodeURIComponent)).filter((p) => p.length === 2))
}

function userFromReq(req) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '') || req.query.token || readCookies(req)[COOKIE]
  if (!token) return null
  const row = db.prepare(
    `SELECT u.* FROM auth_sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ? AND s.expires_at > datetime('now')`
  ).get(String(token))
  return row || null
}

/** Credenciais de IA: preferência para a chave do usuário, depois .env. */
function credsFor(user) {
  const provider = user.ai_provider || ENV_PROVIDER || 'mock'
  const apiKey = (user.ai_key_enc && decrypt(user.ai_key_enc)) || ENV_KEY || null
  return { provider, apiKey }
}

function auth(handler) {
  return (req, res, next) => {
    const user = userFromReq(req)
    if (!user) return res.status(401).json({ error: 'Faça login para continuar.' })
    req.user = user
    Promise.resolve(handler(req, res)).catch(next)
  }
}

/* --------------------------------- rotas ---------------------------------- */

app.get('/api/health', (_req, res) => res.json({ ok: true, provider: ENV_PROVIDER || 'mock', env_key: Boolean(ENV_KEY) }))

app.post('/api/auth/register', (req, res) => {
  const { name, email, password, cefr_level = 'A1', goal = 'conversacao', daily_goal_min = 15 } = req.body || {}
  if (!name?.trim() || !email?.trim() || !password || password.length < 6) {
    return res.status(400).json({ error: 'Preencha nome, e-mail e uma senha com pelo menos 6 caracteres.' })
  }
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.status(400).json({ error: 'E-mail inválido.' })
  if (db.prepare('SELECT 1 FROM users WHERE lower(email) = lower(?)').get(email)) {
    return res.status(409).json({ error: 'Já existe uma conta com esse e-mail.' })
  }
  const level = LEVELS.some((l) => l.id === cefr_level) ? cefr_level : 'A1'
  const info = db.prepare(
    'INSERT INTO users (name, email, password_hash, cefr_level, goal, daily_goal_min) VALUES (?,?,?,?,?,?)'
  ).run(name.trim(), email.trim(), hashPassword(password), level, goal, Number(daily_goal_min) || 15)

  const token = crypto.randomBytes(32).toString('hex')
  db.prepare(`INSERT INTO auth_sessions (token, user_id, expires_at) VALUES (?, ?, datetime('now', '+30 days'))`).run(token, info.lastInsertRowid)
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid)
  res.cookie?.(COOKIE, token, { httpOnly: true, sameSite: 'lax' })
  res.setHeader('set-cookie', `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000`)
  res.json({ token, user: publicUser(user) })
})

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body || {}
  const user = db.prepare('SELECT * FROM users WHERE lower(email) = lower(?)').get(String(email || ''))
  if (!user || !verifyPassword(String(password || ''), user.password_hash)) {
    return res.status(401).json({ error: 'E-mail ou senha incorretos.' })
  }
  const token = crypto.randomBytes(32).toString('hex')
  db.prepare(`INSERT INTO auth_sessions (token, user_id, expires_at) VALUES (?, ?, datetime('now', '+30 days'))`).run(token, user.id)
  res.setHeader('set-cookie', `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000`)
  res.json({ token, user: publicUser(user) })
})

app.post('/api/auth/logout', auth((req, res) => {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '') || readCookies(req)[COOKIE]
  if (token) db.prepare('DELETE FROM auth_sessions WHERE token = ?').run(token)
  res.json({ ok: true })
}))

app.get('/api/me', auth((req, res) => res.json({ user: publicUser(req.user) })))

app.patch('/api/me', auth((req, res) => {
  const { name, cefr_level, goal, daily_goal_min, tts_voice } = req.body || {}
  const sets = []
  const vals = []
  if (name?.trim()) { sets.push('name = ?'); vals.push(name.trim()) }
  if (cefr_level && LEVELS.some((l) => l.id === cefr_level)) { sets.push('cefr_level = ?'); vals.push(cefr_level) }
  if (goal && GOALS.some((g) => g.id === goal)) { sets.push('goal = ?'); vals.push(goal) }
  if (daily_goal_min) { sets.push('daily_goal_min = ?'); vals.push(Math.max(5, Math.min(120, Number(daily_goal_min)))) }
  if (tts_voice?.trim()) { sets.push('tts_voice = ?'); vals.push(tts_voice.trim()) }
  if (sets.length) db.prepare(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`).run(...vals, req.user.id)
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) })
}))

app.put('/api/me/ai-key', auth((req, res) => {
  const { provider, api_key } = req.body || {}
  if (!SUPPORTED_PROVIDERS.includes(provider)) return res.status(400).json({ error: 'Provedor não suportado.' })
  if (!api_key?.trim()) return res.status(400).json({ error: 'Informe a chave de API.' })
  db.prepare('UPDATE users SET ai_provider = ?, ai_key_enc = ? WHERE id = ?').run(provider, encrypt(api_key.trim()), req.user.id)
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)
  res.json({ user: publicUser(user), message: 'Chave salva e criptografada com AES-256-GCM.' })
}))

app.delete('/api/me/ai-key', auth((req, res) => {
  db.prepare('UPDATE users SET ai_provider = NULL, ai_key_enc = NULL WHERE id = ?').run(req.user.id)
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) })
}))

app.post('/api/ai/test', auth(async (req, res) => {
  const { provider, apiKey } = credsFor(req.user)
  const result = await tutorTurn({
    provider,
    apiKey,
    system: 'Reply with only this JSON: {"reply":"pong"}.',
    messages: [{ role: 'user', content: 'ping' }],
    lesson: null,
  })
  res.json({ provider: result.provider, degraded: result.degraded, reply: result.reply, error: result.error || null })
}))

app.get('/api/curriculum', auth((req, res) => {
  const lessons = planForLevel(req.user.cefr_level)
  const progress = db.prepare('SELECT lesson_id, status, best_score FROM lesson_progress WHERE user_id = ?').all(req.user.id)
  const byLesson = Object.fromEntries(progress.map((p) => [p.lesson_id, p]))
  res.json({
    levels: LEVELS, goals: GOALS, freeTopics: FREE_TOPICS,
    units: unitsFor(lessons).map((u) => ({
      ...u,
      lessons: u.lessons.map((l) => ({
        id: l.id, title: l.title, scenario: l.scenario, focus: l.focus, level: l.level,
        objectives: l.objectives, phrases: l.phrases,
        status: byLesson[l.id]?.status || 'available',
        best_score: byLesson[l.id]?.best_score ?? null,
      })),
    })),
  })
}))

app.get('/api/stats', auth((req, res) => {
  const days = db.prepare('SELECT day, xp, turns, seconds FROM daily_stats WHERE user_id = ? ORDER BY day DESC LIMIT 14').all(req.user.id)
  const totals = db.prepare(`
    SELECT (SELECT COUNT(*) FROM conversations WHERE user_id = ?) AS conversations,
           (SELECT COUNT(*) FROM messages m JOIN conversations c ON c.id = m.conversation_id WHERE c.user_id = ? AND m.role='user') AS turns,
           (SELECT COUNT(*) FROM vocab WHERE user_id = ?) AS words,
           (SELECT COUNT(*) FROM lesson_progress WHERE user_id = ? AND status='completed') AS lessons_done
  `).get(req.user.id, req.user.id, req.user.id, req.user.id)
  const dueVocab = db.prepare('SELECT COUNT(*) AS n FROM vocab WHERE user_id = ? AND due_day <= ?').get(req.user.id, today()).n
  const last7 = []
  for (let i = 6; i >= 0; i--) {
    const day = dayOffset(-i)
    const row = days.find((d) => d.day === day)
    last7.push({ day, xp: row?.xp || 0, turns: row?.turns || 0, minutes: Math.round((row?.seconds || 0) / 60) })
  }
  const todayRow = days.find((d) => d.day === today()) || { xp: 0, turns: 0, seconds: 0 }
  res.json({
    xp: req.user.xp, streak: req.user.streak, best_streak: req.user.best_streak, level: req.user.cefr_level,
    daily_goal_min: req.user.daily_goal_min,
    today: { xp: todayRow.xp, turns: todayRow.turns, minutes: Math.round((todayRow.seconds || 0) / 60) },
    totals: { ...totals, due_vocab: dueVocab }, last7,
  })
}))

app.get('/api/vocab', auth((req, res) => {
  const items = db.prepare('SELECT * FROM vocab WHERE user_id = ? ORDER BY due_day ASC, id DESC LIMIT 200').all(req.user.id)
  res.json({ items: items.map((i) => ({ ...i, due: i.due_day <= today() })) })
}))

app.post('/api/vocab', auth((req, res) => {
  const { term, meaning = '', example = '', lesson_id = null } = req.body || {}
  if (!term?.trim()) return res.status(400).json({ error: 'Informe o termo.' })
  const exists = db.prepare('SELECT * FROM vocab WHERE user_id = ? AND lower(term) = lower(?)').get(req.user.id, term.trim())
  if (exists) return res.json({ item: { ...exists, due: exists.due_day <= today() }, duplicate: true })
  const info = db.prepare('INSERT INTO vocab (user_id, term, meaning, example, lesson_id, due_day) VALUES (?,?,?,?,?,?)')
    .run(req.user.id, term.trim(), meaning, example, lesson_id, dayOffset(1))
  res.json({ item: { ...db.prepare('SELECT * FROM vocab WHERE id = ?').get(info.lastInsertRowid), due: false } })
}))

app.post('/api/vocab/:id/review', auth((req, res) => {
  const { correct } = req.body || {}
  const item = db.prepare('SELECT * FROM vocab WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id)
  if (!item) return res.status(404).json({ error: 'Item não encontrado.' })
  const intervals = [1, 2, 4, 8, 16, 32]
  const box = correct ? Math.min(item.box + 1, intervals.length - 1) : 0
  const due = dayOffset(intervals[box])
  db.prepare('UPDATE vocab SET box = ?, due_day = ?, reviews = reviews + 1, correct = correct + ? WHERE id = ?')
    .run(box, due, correct ? 1 : 0, item.id)
  if (correct) addXp(req.user.id, 4)
  res.json({ ok: true, box, due_day: due, xp: correct ? 4 : 0 })
}))

app.delete('/api/vocab/:id', auth((req, res) => {
  db.prepare('DELETE FROM vocab WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id)
  res.json({ ok: true })
}))

/* ------------------------------ conversação ------------------------------- */

function recurringMistakes(userId, limit = 4) {
  const rows = db.prepare(
    `SELECT m.payload FROM messages m JOIN conversations c ON c.id = m.conversation_id
     WHERE c.user_id = ? AND m.role = 'tutor' AND m.payload IS NOT NULL ORDER BY m.id DESC LIMIT 40`
  ).all(userId)
  const counts = new Map()
  for (const r of rows) {
    try {
      const p = JSON.parse(r.payload)
      if (p?.correction?.has_error && p.correction.explanation) {
        counts.set(p.correction.explanation, (counts.get(p.correction.explanation) || 0) + 1)
      }
    } catch {}
  }
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit).map(([k, v]) => `${k} (x${v})`)
}

app.post('/api/conv/start', auth((req, res) => {
  const { lesson_id = null, level } = req.body || {}
  const lesson = lesson_id ? byId(lesson_id) : null
  const useLevel = lesson?.level || (LEVELS.some((l) => l.id === level) ? level : req.user.cefr_level)
  const title = lesson ? lesson.title : 'Free talk'
  const info = db.prepare('INSERT INTO conversations (user_id, lesson_id, title, level) VALUES (?,?,?,?)')
    .run(req.user.id, lesson_id, title, useLevel)
  const opener = lesson?.opener || 'Hi! I’m Alex, your English tutor. Let’s just talk — tell me, how has your week been so far?'
  db.prepare('INSERT INTO messages (conversation_id, role, content, payload) VALUES (?,?,?,?)')
    .run(info.lastInsertRowid, 'tutor', opener, JSON.stringify({ correction: { has_error: false }, vocab: [], hint: '', opener: true }))
  if (lesson_id) {
    db.prepare(
      `INSERT INTO lesson_progress (user_id, lesson_id, status, attempts) VALUES (?,?, 'in_progress', 1)
       ON CONFLICT(user_id, lesson_id) DO UPDATE SET status = CASE WHEN lesson_progress.status = 'completed' THEN 'completed' ELSE 'in_progress' END,
       attempts = lesson_progress.attempts + 1, last_at = datetime('now')`
    ).run(req.user.id, lesson_id)
  }
  touchStreak(req.user.id)
  res.json({
    conversation: { id: info.lastInsertRowid, title, level: useLevel, lesson_id },
    messages: [{ role: 'tutor', content: opener, payload: { correction: { has_error: false }, vocab: [], hint: '' } }],
    lesson: lesson ? { id: lesson.id, title: lesson.title, scenario: lesson.scenario, focus: lesson.focus, objectives: lesson.objectives, phrases: lesson.phrases } : null,
  })
}))

app.post('/api/conv/:id/message', auth(async (req, res) => {
  const conv = db.prepare('SELECT * FROM conversations WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id)
  if (!conv) return res.status(404).json({ error: 'Conversa não encontrada.' })
  const content = String(req.body?.content || '').trim()
  if (!content) return res.status(400).json({ error: 'Mensagem vazia.' })
  if (content.length > 1500) return res.status(400).json({ error: 'Mensagem muito longa.' })

  db.prepare('INSERT INTO messages (conversation_id, role, content) VALUES (?,?,?)').run(conv.id, 'user', content)

  const lesson = conv.lesson_id ? byId(conv.lesson_id) : null
  const history = db.prepare('SELECT role, content FROM messages WHERE conversation_id = ? ORDER BY id ASC LIMIT 30').all(conv.id)
  const system = buildSystemPrompt({
    lesson,
    level: conv.level,
    goal: req.user.goal,
    userName: req.user.name.split(' ')[0],
    recurring: recurringMistakes(req.user.id),
  })

  const { provider, apiKey } = credsFor(req.user)
  const result = await tutorTurn({ provider, apiKey, system, messages: history.map((h) => ({ role: h.role === 'user' ? 'user' : 'assistant', content: h.content })), lesson })

  const payload = { correction: result.correction, vocab: result.vocab, hint: result.hint, provider: result.provider, degraded: result.degraded, error: result.error }
  const info = db.prepare('INSERT INTO messages (conversation_id, role, content, payload) VALUES (?,?,?,?)')
    .run(conv.id, 'tutor', result.reply, JSON.stringify(payload))

  // XP: base por turno + bônus por boa correção + palavras novas sugeridas
  const xp = 10 + (result.correction?.has_error ? 0 : 5) + Math.min(result.vocab?.length || 0, 2) * 2
  addXp(req.user.id, xp, { turns: 1, seconds: 45 })
  db.prepare('UPDATE conversations SET turns = turns + 1, xp = xp + ? WHERE id = ?').run(xp, conv.id)
  const streak = touchStreak(req.user.id)

  res.json({
    message: { id: info.lastInsertRowid, role: 'tutor', content: result.reply, payload },
    xp_awarded: xp,
    streak,
    provider: result.provider,
    degraded: result.degraded,
  })
}))

app.post('/api/conv/:id/end', auth((req, res) => {
  const conv = db.prepare('SELECT * FROM conversations WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id)
  if (!conv) return res.status(404).json({ error: 'Conversa não encontrada.' })
  const total = db.prepare('SELECT COUNT(*) AS n FROM messages WHERE conversation_id = ?').get(conv.id).n
  const studentTurns = db.prepare(`SELECT COUNT(*) AS n FROM messages WHERE conversation_id = ? AND role = 'user'`).get(conv.id).n
  const errors = db.prepare(
    `SELECT COUNT(*) AS n FROM messages WHERE conversation_id = ? AND role = 'tutor' AND payload LIKE '%"has_error":true%'`
  ).get(conv.id).n
  const words = db.prepare(`SELECT content FROM messages WHERE conversation_id = ? AND role = 'user'`).all(conv.id)
    .flatMap((m) => m.content.split(/\s+/).filter(Boolean)).length
  const accuracy = 1 - errors / Math.max(studentTurns * 2, 1)
  const volume = Math.min(studentTurns, 12) / 12
  const score = Math.max(45, Math.min(100, Math.round(45 + accuracy * 35 + volume * 20)))
  const xp = Math.round(score / 4) + 15

  db.prepare(`UPDATE conversations SET ended_at = datetime('now'), score = ?, xp = xp + ? WHERE id = ?`).run(score, xp, conv.id)
  if (conv.lesson_id) {
    db.prepare(
      `INSERT INTO lesson_progress (user_id, lesson_id, status, best_score, last_at) VALUES (?,?, 'completed', ?, datetime('now'))
       ON CONFLICT(user_id, lesson_id) DO UPDATE SET status = 'completed',
       best_score = MAX(COALESCE(lesson_progress.best_score, 0), excluded.best_score), last_at = datetime('now')`
    ).run(req.user.id, conv.lesson_id, score)
  }
  addXp(req.user.id, xp, { seconds: Math.max(0, studentTurns * 20) })
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)
  const vocab = db.prepare('SELECT id, term, meaning FROM vocab WHERE user_id = ? ORDER BY id DESC LIMIT 4').all(req.user.id)

  res.json({
    summary: {
      conversation_id: conv.id, title: conv.title, level: conv.level, lesson_id: conv.lesson_id,
      student_turns: studentTurns, messages: total, words_spoken: words, corrections: errors,
      duration_min: Math.max(1, Math.round((studentTurns * 20) / 60)), score, xp_awarded: xp,
    },
    streak: { streak: user.streak, best: user.best_streak },
    vocab,
    next_lesson: nextLessonFor(req.user, conv.lesson_id),
  })
}))

function nextLessonFor(user, currentLessonId) {
  const plan = planForLevel(user.cefr_level)
  const done = new Set(db.prepare(`SELECT lesson_id FROM lesson_progress WHERE user_id = ? AND status = 'completed'`).all(user.id).map((r) => r.lesson_id))
  const idx = plan.findIndex((l) => l.id === currentLessonId)
  const pool = idx >= 0 ? [...plan.slice(idx + 1), ...plan.slice(0, idx)] : plan
  const next = pool.find((l) => !done.has(l.id)) || pool[0]
  return next ? { id: next.id, title: next.title, level: next.level, scenario: next.scenario } : null
}

app.get('/api/conv', auth((req, res) => {
  const rows = db.prepare(`
    SELECT c.id, c.title, c.level, c.lesson_id, c.started_at, c.ended_at, c.xp, c.turns, c.score,
      (SELECT COUNT(*) FROM messages m WHERE m.conversation_id = c.id AND m.role = 'user') AS student_turns
    FROM conversations c WHERE c.user_id = ? ORDER BY c.id DESC LIMIT 50
  `).all(req.user.id)
  res.json({ conversations: rows })
}))

app.get('/api/conv/:id', auth((req, res) => {
  const conv = db.prepare('SELECT * FROM conversations WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id)
  if (!conv) return res.status(404).json({ error: 'Conversa não encontrada.' })
  const messages = db.prepare('SELECT role, content, payload, created_at FROM messages WHERE conversation_id = ? ORDER BY id ASC').all(conv.id)
  res.json({
    conversation: conv,
    lesson: conv.lesson_id ? byId(conv.lesson_id) : null,
    messages: messages.map((m) => {
      let payload = null
      try { payload = m.payload ? JSON.parse(m.payload) : null } catch {}
      return { role: m.role, content: m.content, payload, created_at: m.created_at }
    }),
  })
}))

app.post('/api/tts', auth(async (req, res) => {
  const text = String(req.body?.text || '').trim()
  if (!text) return res.status(400).json({ error: 'Texto vazio.' })
  const { provider, apiKey } = credsFor(req.user)
  const audio = await synthesize(text, { provider, apiKey, voice: req.user.tts_voice })
  if (!audio) return res.status(204).end() // cliente usa a voz do navegador
  res.setHeader('content-type', audio.mime)
  res.setHeader('cache-control', 'no-store')
  res.send(audio.buffer)
}))

/* ------------------------------- front-end -------------------------------- */

const dist = path.join(process.cwd(), 'dist')
if (fs.existsSync(dist)) {
  app.use(express.static(dist))
  app.get(/^(?!\/api\/).*/, (_req, res) => res.sendFile(path.join(dist, 'index.html')))
} else {
  app.get('/', (_req, res) =>
    res
      .status(200)
      .type('html')
      .send(`<html lang="pt-BR"><meta charset="utf-8"><body style="font-family:system-ui;padding:48px;max-width:640px;margin:auto;line-height:1.6">
      <h1>Fluenta · API no ar ✅</h1>
      <p>O front-end de desenvolvimento roda à parte por padrão: <code>npm run dev</code> (Vite em
      <a href="http://localhost:5173">localhost:5173</a>, com proxy para <code>/api</code>).</p>
      <p>Para servir tudo em um único endereço: <code>npm run build</code> e depois <code>npm start</code>.</p>
      <p>Provedor de IA no servidor: <b>${ENV_PROVIDER || 'mock (demo)'}</b> · chave via .env: <b>${ENV_KEY ? 'sim' : 'não'}</b></p>
      </body></html>`)
  )
}

app.use((err, _req, res, _next) => {
  console.error('[erro]', err)
  res.status(500).json({ error: 'Erro interno no servidor.' })
})

app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  Fluenta API  →  http://0.0.0.0:${PORT}`)
  console.log(`  IA no servidor: ${ENV_PROVIDER || 'mock (modo demonstração)'}${ENV_KEY ? ' · chave via .env' : ''}\n`)
})
