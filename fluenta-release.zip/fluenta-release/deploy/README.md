# Hospedar o Fluenta para uso pessoal

O Fluenta completo precisa de um processo Node/Express e de um disco persistente para o SQLite.
A imagem `Dockerfile` já faz o build do React e inicia API + front no mesmo endereço.

## Caminho simples: Render

1. Crie um repositório privado no GitHub e envie o conteúdo desta pasta.
2. No Render, escolha **New → Blueprint** e selecione o repositório.
3. O Render lê `render.yaml`.
4. Confirme o serviço `fluenta-pessoal` e o disco montado em `/data`.
5. Faça o deploy e abra a URL gerada.
6. Sem `AI_API_KEY`, o app funciona com o tutor local de demonstração. Para IA real, adicione `AI_PROVIDER` e `AI_API_KEY` como variáveis secretas.

> O banco está em `/data/fluenta.db`. Não remova o disco persistente, ou contas, conversas e vocabulário serão perdidos em um novo deploy.

## Docker em um VPS

```bash
docker build -t fluenta .
docker volume create fluenta-data
docker run -d --name fluenta \
  -p 80:10000 \
  -v fluenta-data:/data \
  -e SERVER_SECRET='troque-por-uma-frase-secreta-longa' \
  fluenta
```

Antes de abrir para a internet, coloque HTTPS com Caddy ou Nginx e não publique a chave de IA no front-end.

## Demo estática

A versão sem servidor está em `static-site/index.html`. Ela pode ser publicada em Netlify, Vercel ou GitHub Pages, mas não tem login, banco, IA externa nem histórico persistente.
